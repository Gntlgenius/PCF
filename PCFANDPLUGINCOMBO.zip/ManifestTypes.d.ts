/*
  Stub — regenerate with:  npm run refreshTypes
  after running:  pac pcf init
*/
export interface IInputs {
  flagsJson: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {}
