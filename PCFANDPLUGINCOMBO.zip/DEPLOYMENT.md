# Client Flag Viewer — Deployment Guide

## Prerequisites
- Power Platform CLI (`pac`) installed and authenticated
- Visual Studio or dotnet CLI for the plugin
- Plugin Registration Tool
- `acc_clientflagsjson` field (Multiple Lines of Text) created on `acc_client`

---

## 1 — Create the field in Dataverse

| Setting       | Value                        |
|---------------|------------------------------|
| Display name  | Client Flags JSON            |
| Logical name  | acc_clientflagsjson          |
| Data type     | Multiple Lines of Text       |
| Max length    | 1048576 (max)                |

---

## 2 — Build and deploy the Plugin

```bash
cd Plugin
dotnet build -c Release
```

Then in the Plugin Registration Tool:

1. Connect to your environment
2. Register new assembly → select `Acc.ClientFlags.Plugin.dll`
3. Register **two** steps (see REGISTRATION.md):
   - Associate   → Post-operation → Synchronous
   - Disassociate → Post-operation → Synchronous

**Test**: Open an acc_client record, add/remove a flag via the web resource IFrame.
Check that `acc_clientflagsjson` updates immediately on the record.

Sample JSON you should see:
```json
[
  {"id":"abc-123","name":"Violence","iconUrl":"/WebResources/acc_violence_icon","isActive":true},
  {"id":"def-456","name":"Drugs","iconUrl":"/WebResources/acc_drugs_icon","isActive":false}
]
```

---

## 3 — Build and deploy the PCF

```bash
cd PCF/ClientFlagViewer

# Install dependencies
npm install

# Regenerate manifest types (replaces the stub)
npm run refreshTypes

# Build
npm run build

# Push to your environment
pac pcf push --publisher-prefix acc
```

---

## 4 — Add the PCF to your view

1. Open **Power Apps** → your solution → **Views** on `acc_client`
2. Add `acc_clientflagsjson` as a column
3. Select the column → **Change component** → select **Client Flag Viewer**
4. Enable for **Web**, **Phone**, **Tablet**
5. **Save and Publish**

---

## How it works end-to-end

```
User adds/removes flag on the form
        ↓
FlagJsonWriter plugin fires (Post-operation)
        ↓
Queries all acc_clientflag definitions + linked flags for this client
        ↓
Writes full JSON array to acc_clientflagsjson
        ↓
User opens the view
        ↓
PCF updateView() fires per row — reads acc_clientflagsjson
        ↓
Parses JSON → filters isActive:true → renders badge pills
SVG icons fetched once per unique iconUrl, cached for the session
```

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| JSON field empty after flag change | Plugin not registered or firing on wrong entity | Check step registration — Primary Entity must be `acc_client` |
| Badges show fallback icon | `acc_iconurl` is empty or path wrong | Check acc_clientflag records have valid `/WebResources/...` paths |
| PCF shows `—` for all rows | Field not bound correctly | Ensure column in view uses `acc_clientflagsjson` bound to Client Flag Viewer |
| Icons 404 in view | Web resource not published | Publish all customisations after uploading SVG web resources |
