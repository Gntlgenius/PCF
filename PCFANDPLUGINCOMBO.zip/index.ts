import { IInputs, IOutputs } from "./generated/ManifestTypes";

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// JSON shape written by the FlagJsonWriter plugin.
// Every flag in the system is present; isActive=true means linked to this client.
// ─────────────────────────────────────────────────────────────────────────────
interface FlagJsonEntry {
  id:       string;
  name:     string;
  iconUrl:  string;
  isActive: boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// CSS — from :root in your OffenderFlags web resource
// ─────────────────────────────────────────────────────────────────────────────
const CSS = {
  font:        "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
  iconBg:      "#F5F4F0",
  iconBorder:  "#E8E6DF",
  iconColor:   "#A19F9D",
  pillBg:      "#F5F4F0",
  pillBorder:  "#E8E6DF",
  pillText:    "#605E5C",
  textHint:    "#A19F9D",
};

// ─────────────────────────────────────────────────────────────────────────────
// FALLBACK SVG — identical to FALLBACK_SVG in your web resource
// ─────────────────────────────────────────────────────────────────────────────
const FALLBACK_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
  style="width:13px;height:13px;display:block">
  <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
  <line x1="4" y1="22" x2="4" y2="15"/>
</svg>`;

// ─────────────────────────────────────────────────────────────────────────────
// MODULE-LEVEL SVG CACHE
// Shared across every row in the view — same pattern as your web resource.
// Each unique iconUrl is fetched only once per page session.
// ─────────────────────────────────────────────────────────────────────────────
const _svgCache = new Map<string, string>();

// Track in-flight fetches so concurrent rows don't duplicate requests
const _svgFetching = new Map<string, Promise<string>>();

/**
 * Resolve a web resource URL to an absolute URL.
 * Mirrors the same logic in your OffenderFlags web resource fetchSvg().
 */
function resolveUrl(url: string): string {
  if (!url) return "";
  return url.startsWith("http")
    ? url
    : window.location.origin + (url.startsWith("/") ? url : "/" + url);
}

/**
 * Fetch an SVG web resource and return its markup.
 * Identical logic to fetchSvg() in your web resource.
 * Returns cached value immediately on subsequent calls.
 */
function fetchSvg(url: string): Promise<string> {
  if (!url) return Promise.resolve(FALLBACK_SVG);

  const resolved = resolveUrl(url);
  if (_svgCache.has(resolved))   return Promise.resolve(_svgCache.get(resolved)!);
  if (_svgFetching.has(resolved)) return _svgFetching.get(resolved)!;

  const job = fetch(resolved, { credentials: "same-origin" })
    .then(res => {
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.text();
    })
    .then(text => {
      const match = text.match(/<svg[\s\S]*<\/svg>/i);
      const svg   = match ? match[0] : FALLBACK_SVG;
      const sized = svg.replace(/<svg/, '<svg style="width:13px;height:13px;display:block" ');
      _svgCache.set(resolved, sized);
      return sized;
    })
    .catch(err => {
      console.warn("[ClientFlagViewer] SVG fetch failed:", resolved, (err as Error).message);
      _svgCache.set(resolved, FALLBACK_SVG);
      return FALLBACK_SVG;
    })
    .finally(() => {
      _svgFetching.delete(resolved);
    });

  _svgFetching.set(resolved, job);
  return job;
}

/**
 * Pre-fetch all unique icon URLs from the parsed flag array.
 * Mirrors prefetchAllIcons() in your web resource.
 * Called once on init when the first JSON value is available.
 */
function prefetchIcons(flags: FlagJsonEntry[]): void {
  const urls = [...new Set(flags.map(f => f.iconUrl).filter(Boolean))];
  urls.forEach(url => fetchSvg(url)); // fire-and-forget, results cached
}

// ─────────────────────────────────────────────────────────────────────────────
// PCF CONTROL
// ─────────────────────────────────────────────────────────────────────────────
export class ClientFlagViewer
  implements ComponentFramework.StandardControl<IInputs, IOutputs>
{
  private _root:      HTMLDivElement;
  private _lastRaw:   string  = "__UNINIT__";
  private _destroyed: boolean = false;

  // ── init ──────────────────────────────────────────────────────────────────
  public init(
    context:             ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    _state:              ComponentFramework.Dictionary,
    container:           HTMLDivElement
  ): void {
    this._root = document.createElement("div");
    this._root.style.cssText =
      `display:flex;flex-wrap:wrap;gap:4px;align-items:center;` +
      `padding:2px 0;font-family:${CSS.font};`;
    container.appendChild(this._root);
  }

  // ── updateView ────────────────────────────────────────────────────────────
  // Called by the platform for every row when the view renders.
  // This is the ONLY entry point — no WebAPI calls here.
  // ─────────────────────────────────────────────────────────────────────────
  public updateView(context: ComponentFramework.Context<IInputs>): void {
    const raw = (context.parameters.flagsJson.raw || "").trim();

    // Skip re-render if the value hasn't changed for this row
    if (raw === this._lastRaw) return;
    this._lastRaw = raw;

    if (!raw) {
      this._renderEmpty();
      return;
    }

    // ── Parse JSON ────────────────────────────────────────────────────────
    let allFlags: FlagJsonEntry[];
    try {
      allFlags = JSON.parse(raw) as FlagJsonEntry[];
    } catch {
      this._renderEmpty("—");
      return;
    }

    if (!Array.isArray(allFlags) || allFlags.length === 0) {
      this._renderEmpty();
      return;
    }

    // Pre-fetch all icons the first time we see a non-empty JSON value.
    // After this call every icon URL is in-flight or cached — subsequent
    // rows hit the cache and pay zero network cost.
    prefetchIcons(allFlags);

    // ── Filter to active flags only ───────────────────────────────────────
    const active = allFlags.filter(f => f.isActive === true);

    if (active.length === 0) {
      this._renderEmpty();
      return;
    }

    // ── Render badges ─────────────────────────────────────────────────────
    // SVGs are almost certainly already cached from prefetchIcons().
    // For the rare case they aren't yet, we patch the icon in-place
    // when the fetch resolves.
    this._renderBadges(active);
  }

  // ── _renderEmpty ──────────────────────────────────────────────────────────
  private _renderEmpty(msg = "—"): void {
    this._root.innerHTML = "";
    const span = document.createElement("span");
    span.style.cssText =
      `font-size:11px;color:${CSS.textHint};font-family:${CSS.font};`;
    span.textContent = msg;
    this._root.appendChild(span);
  }

  // ── _renderBadges ─────────────────────────────────────────────────────────
  // One pill badge per active flag.
  // Style mirrors .summary-chip + .flag-icon-wrap in your web resource.
  private _renderBadges(flags: FlagJsonEntry[]): void {
    this._root.innerHTML = "";

    flags.forEach(flag => {
      // ── Pill ──────────────────────────────────────────────────────────────
      const pill = document.createElement("span");
      pill.title = flag.name;
      pill.style.cssText =
        `display:inline-flex;align-items:center;gap:5px;` +
        `padding:2px 8px 2px 4px;border-radius:999px;` +
        `font-size:10px;font-weight:500;font-family:${CSS.font};` +
        `background:${CSS.pillBg};color:${CSS.pillText};` +
        `border:.5px solid ${CSS.pillBorder};white-space:nowrap;line-height:1.4;`;

      // ── Icon wrap ─────────────────────────────────────────────────────────
      // Mirrors .flag-icon-wrap in your web resource
      const iconWrap = document.createElement("span");
      iconWrap.style.cssText =
        `width:20px;height:20px;border-radius:5px;` +
        `display:inline-flex;align-items:center;justify-content:center;` +
        `background:${CSS.iconBg};border:.5px solid ${CSS.iconBorder};` +
        `color:${CSS.iconColor};flex-shrink:0;`;

      // Populate icon from cache if available
      const resolved   = resolveUrl(flag.iconUrl);
      const cachedSvg  = resolved ? _svgCache.get(resolved) : null;
      iconWrap.innerHTML = cachedSvg || FALLBACK_SVG;

      // If not cached yet, patch in-place when fetch resolves
      if (flag.iconUrl && !cachedSvg) {
        fetchSvg(flag.iconUrl).then(svg => {
          if (!this._destroyed) iconWrap.innerHTML = svg;
        });
      }

      // ── Label ─────────────────────────────────────────────────────────────
      const label = document.createElement("span");
      label.textContent = flag.name;

      pill.appendChild(iconWrap);
      pill.appendChild(label);
      this._root.appendChild(pill);
    });
  }

  // ── getOutputs ────────────────────────────────────────────────────────────
  public getOutputs(): IOutputs {
    return {};
  }

  // ── destroy ───────────────────────────────────────────────────────────────
  public destroy(): void {
    this._destroyed = true;
  }
}
