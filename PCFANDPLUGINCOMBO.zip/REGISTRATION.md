# Plugin Registration — FlagJsonWriter

## Assembly
  Acc.ClientFlags.Plugin.dll

## Class
  Acc.ClientFlags.Plugin.FlagJsonWriter

## Steps to register (Plugin Registration Tool)

Register TWO steps on the same class:

### Step 1 — Associate
| Field              | Value                              |
|--------------------|------------------------------------|
| Message            | Associate                          |
| Primary Entity     | acc_client                         |
| Secondary Entity   | acc_clientflag                     |
| Execution Mode     | Synchronous                        |
| Stage              | Post-operation                     |
| Deployment         | Server                             |
| Execution Order    | 1                                  |

### Step 2 — Disassociate
| Field              | Value                              |
|--------------------|------------------------------------|
| Message            | Disassociate                       |
| Primary Entity     | acc_client                         |
| Secondary Entity   | acc_clientflag                     |
| Execution Mode     | Synchronous                        |
| Stage              | Post-operation                     |
| Deployment         | Server                             |
| Execution Order    | 1                                  |

## Notes
- No Secure / Unsecure config needed
- No image registration needed — the plugin re-queries live data
- Sign the assembly with a strong-name key before deploying to production
