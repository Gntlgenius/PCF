using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;

namespace Acc.ClientFlags.Plugin
{
    // ─────────────────────────────────────────────────────────────────────────
    // FlagJsonWriter
    //
    // Fires on the N:N relationship table (acc_client_acc_clientflag) after
    // an Associate or Disassociate message so that acc_clientflagsjson on the
    // acc_client record is always in sync with the current set of linked flags.
    //
    // Registration (Plugin Registration Tool):
    //   Entity:   acc_client_acc_clientflag   (the N:N intersect entity)
    //   Message:  Associate   → Post-Operation, Synchronous
    //   Message:  Disassociate → Post-Operation, Synchronous
    //
    // Secure / Unsecure config: not required.
    // ─────────────────────────────────────────────────────────────────────────
    public class FlagJsonWriter : IPlugin
    {
        // ── Column names ──────────────────────────────────────────────────────
        private const string ClientEntity        = "acc_client";
        private const string ClientPrimaryKey    = "acc_clientid";
        private const string ClientJsonField     = "acc_clientflagsjson";   // Multiline Text on acc_client

        private const string FlagEntity         = "acc_clientflag";
        private const string FlagPrimaryKey     = "acc_clientflagid";
        private const string FlagNameField      = "acc_name";
        private const string FlagIconUrlField   = "acc_iconurl";
        private const string FlagIsActiveField  = "acc_isactive";

        private const string RelationshipName   = "acc_client_acc_clientflag";

        // ─────────────────────────────────────────────────────────────────────
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)
                serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var tracer  = (ITracingService)
                serviceProvider.GetService(typeof(ITracingService));

            try
            {
                // Both Associate and Disassociate pass the target as an
                // EntityReference and the related entities in InputParameters.
                var target = context.InputParameters.Contains("Target")
                    ? context.InputParameters["Target"] as EntityReference
                    : null;

                if (target == null || target.LogicalName != ClientEntity)
                {
                    // Message may fire for the reverse direction — ignore
                    tracer.Trace("Target is not acc_client — skipping.");
                    return;
                }

                Guid clientId = target.Id;
                tracer.Trace($"FlagJsonWriter firing for client: {clientId}");

                // 1. Load ALL active flag definitions
                var allFlags = LoadAllFlagDefinitions(service, tracer);
                tracer.Trace($"Loaded {allFlags.Count} flag definitions.");

                // 2. Load the IDs of flags currently linked to this client
                var activeIds = LoadActiveFlagIds(service, clientId, tracer);
                tracer.Trace($"Client has {activeIds.Count} active flags.");

                // 3. Build the JSON array — every flag is included,
                //    isActive = true only if linked to this client
                var flagArray = allFlags.Select(f => new FlagJsonEntry
                {
                    Id        = f.Id.ToString("D"),
                    Name      = f.Name,
                    IconUrl   = f.IconUrl,
                    IsActive  = activeIds.Contains(f.Id),
                }).ToList();

                string json = JsonConvert.SerializeObject(
                    flagArray,
                    Formatting.None,
                    new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }
                );

                tracer.Trace($"Writing JSON ({json.Length} chars) to {ClientJsonField}.");

                // 4. Update acc_clientflagsjson on the client record
                var update = new Entity(ClientEntity, clientId);
                update[ClientJsonField] = json;
                service.Update(update);

                tracer.Trace("FlagJsonWriter completed successfully.");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(
                    $"FlagJsonWriter failed: {ex.Message}", ex);
            }
        }

        // ── Load all active flag definitions ──────────────────────────────────
        // Returns every acc_clientflag where acc_isactive = true,
        // ordered by name so the JSON is deterministic.
        private List<FlagDefinition> LoadAllFlagDefinitions(
            IOrganizationService service,
            ITracingService tracer)
        {
            var query = new QueryExpression(FlagEntity)
            {
                ColumnSet = new ColumnSet(
                    FlagPrimaryKey,
                    FlagNameField,
                    FlagIconUrlField,
                    FlagIsActiveField),
                Criteria = new FilterExpression(LogicalOperator.And),
            };

            query.Criteria.AddCondition(
                FlagIsActiveField, ConditionOperator.Equal, true);

            query.AddOrder(FlagNameField, OrderType.Ascending);

            var results = service.RetrieveMultiple(query);

            return results.Entities.Select(e => new FlagDefinition
            {
                Id      = e.Id,
                Name    = e.Contains(FlagNameField)
                            ? e.GetAttributeValue<string>(FlagNameField) ?? string.Empty
                            : string.Empty,
                IconUrl = e.Contains(FlagIconUrlField)
                            ? e.GetAttributeValue<string>(FlagIconUrlField)?.Trim() ?? string.Empty
                            : string.Empty,
            }).ToList();
        }

        // ── Load IDs of flags currently linked to this client ─────────────────
        // Uses a link-entity query against the N:N intersect to avoid
        // loading the full related entity collection.
        private HashSet<Guid> LoadActiveFlagIds(
            IOrganizationService service,
            Guid clientId,
            ITracingService tracer)
        {
            // Query the intersect table directly via link-entity
            var query = new QueryExpression(FlagEntity)
            {
                ColumnSet = new ColumnSet(FlagPrimaryKey),
            };

            var link = query.AddLink(
                "acc_client_acc_clientflag",   // intersect entity logical name
                FlagPrimaryKey,                 // flag PK
                FlagPrimaryKey);               // intersect FK to flag

            link.LinkCriteria.AddCondition(
                ClientPrimaryKey,
                ConditionOperator.Equal,
                clientId);

            var results = service.RetrieveMultiple(query);
            return new HashSet<Guid>(results.Entities.Select(e => e.Id));
        }

        // ── Internal DTOs ──────────────────────────────────────────────────────
        private class FlagDefinition
        {
            public Guid   Id      { get; set; }
            public string Name    { get; set; }
            public string IconUrl { get; set; }
        }

        // Serialised into the JSON field — matches what the PCF expects
        private class FlagJsonEntry
        {
            [JsonProperty("id")]
            public string Id { get; set; }

            [JsonProperty("name")]
            public string Name { get; set; }

            [JsonProperty("iconUrl")]
            public string IconUrl { get; set; }

            [JsonProperty("isActive")]
            public bool IsActive { get; set; }
        }
    }
}
