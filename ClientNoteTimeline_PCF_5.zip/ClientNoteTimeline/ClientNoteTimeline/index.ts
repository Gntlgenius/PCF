import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { ClientNoteTimelineComponent } from "./components/ClientNoteTimeline";

export class ClientNoteTimeline
  implements ComponentFramework.ReactControl<IInputs, IOutputs>
{
  private _context: ComponentFramework.Context<IInputs>;
  private _notifyOutputChanged: () => void;

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void
  ): void {
    this._context = context;
    this._notifyOutputChanged = notifyOutputChanged;
    // Track container resize so the component fills the subgrid width
    context.mode.trackContainerResize(true);
  }

  public updateView(
    context: ComponentFramework.Context<IInputs>
  ): React.ReactElement {
    this._context = context;

    const dataset = context.parameters.clientNotes;

    // Derive the parent Client GUID from the dataset linking object.
    // When bound as a subgrid with "Show related records", the dataset
    // exposes the parent record id through the linking entity object.
    const linking = (dataset as any).getLinkingEntityReferenceId?.() ?? "";
    const linkingObj = (dataset as any).linking;
    const clientId: string =
      linking ||
      linkingObj?.getLinkedEntityId?.() ||
      linkingObj?.linkedEntityId ||
      "";

    return React.createElement(ClientNoteTimelineComponent, {
      dataset,
      clientId,
      webAPI: context.webAPI,
      navigation: context.navigation,
      utils: context.utils,
      containerWidth: context.mode.allocatedWidth,
      containerHeight: context.mode.allocatedHeight,
    });
  }

  public getOutputs(): IOutputs {
    return {};
  }

  public destroy(): void {}
}
