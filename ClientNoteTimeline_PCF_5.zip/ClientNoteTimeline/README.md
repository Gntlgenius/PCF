# ClientNoteTimeline PCF Control

A custom Power Apps Component Framework (PCF) control that replaces the out-of-the-box Dynamics 365 Timeline with a purpose-built **Client Note Timeline** for the `acc_clientnote` table.

---

## Features

| Feature | Detail |
|---|---|
| **Data source** | `acc_clientnote` table filtered by `acc_clientid` |
| **Colour-coded badges** | `acc_ipfclientstatus` drives badge colour |
| **Clicking the badge** | Opens the full Client Note record |
| **Owner avatar** | Initials extracted from Owner Name, colour-coded by name hash |
| **Position (SPO)** | Reads `jobtitle` from the ownerid expanded lookup |
| **Related To** | Displays `acc_relatedto` formatted value with label "Related to:" |
| **Search** | Real-time filter on title, description, owner, and status label |
| **New Client Note** | Opens the `acc_clientnote` create form pre-filled with `acc_clientid` |
| **Refresh** | Re-queries Dataverse on demand |
| **Vertical timeline** | Avatar + connector line layout matching the design spec |

---

## Field Mapping

| Display | Dataverse Column |
|---|---|
| Case Note Header | `acc_name` |
| Coloured palette / badge | `acc_ipfclientstatus` (Option Set) |
| Created By / initials | `_ownerid_value` (expanded) |
| Position (SPO) | `ownerid.jobtitle` (expanded) |
| Details / body text | `description` |
| Related To value | `acc_relatedto` |
| Filter condition | `acc_clientid eq '<clientGuid>'` |

---

## Prerequisites

- Node.js 16+
- Power Platform CLI (`pac`)
- `.NET SDK` (for solution packaging)

```bash
npm install -g @microsoft/powerapps-pcfexplorer
npm install -g pac
```

---

## Setup & Build

### 1. Install dependencies

```bash
cd ClientNoteTimeline
npm install
```

### 2. Run in test harness

```bash
npm start
```

Open `http://localhost:8181` — set the `clientid` input to a real or test GUID.

### 3. Build for production

```bash
npm run build
```

### 4. Push to your environment

```bash
pac auth create --url https://yourorg.crm.dynamics.com
pac pcf push --publisher-prefix acc
```

---

## Deploying via Solution

```bash
cd Solution
dotnet build
```

Import the generated `.zip` from `Solution/bin/Debug` into your environment via the Power Platform Admin Center or:

```bash
pac solution import --path ./Solution/bin/Debug/ClientNoteTimelineSolution.zip
```

---

## Adding to a Form

This control is designed to sit directly on the **Client record form**.
It reads the current record's GUID automatically via `contextInfo.entityId` — no field binding is needed.

1. Open the **Client** entity form in the form editor.
2. Insert a **1-column section** where you want the timeline to appear.
3. Add any placeholder field into that section (e.g. a dummy text field).
4. In the field's **Controls** tab → **Add Control** → select **ClientNoteTimeline**.
5. Set visibility to **Web**, **Phone**, **Tablet** as needed.
6. **Hide the field label** and set the field to read-only.
7. Save & Publish.

> The control automatically uses the Client record's GUID as the filter — no property mapping required.

---

## Status Badge Colours

Adjust `STATUS_COLOURS` in `components/ClientNoteTimeline.tsx` to match your `acc_ipfclientstatus` option set values:

```typescript
const STATUS_COLOURS: Record<string, string> = {
  "1": "#e74c3c",   // red
  "2": "#e67e22",   // orange
  "3": "#f39c12",   // 3. Planning / CMP
  "4": "#27ae60",   // 4. Manage Change
  "5": "#8e44ad",   // 5. Priorities
  "6": "#2980b9",   // blue
  "7": "#16a085",   // teal
  default: "#95a5a6",
};
```

The **key** is the integer value of the option set item.

---

## Folder Structure

```
ClientNoteTimeline/
├── ClientNoteTimeline/
│   ├── ControlManifest.Input.xml    ← PCF manifest
│   ├── index.ts                     ← PCF entry point
│   └── components/
│       └── ClientNoteTimeline.tsx   ← React UI component
├── Solution/
│   ├── Solution.cdsproj
│   └── src/Other/Solution.xml
├── package.json
└── tsconfig.json
```

---

## Notes

- The control uses **virtual** control type — no dataset binding needed; it calls `webAPI.retrieveMultipleRecords` directly for maximum query flexibility.
- The `ownerid` lookup is expanded to retrieve `jobtitle` for the SPO position display.
- Opening a record uses `navigation.openForm` — works in Model-Driven Apps and Customer Service Hub.
