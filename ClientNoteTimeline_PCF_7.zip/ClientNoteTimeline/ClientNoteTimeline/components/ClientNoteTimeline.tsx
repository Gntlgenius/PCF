import * as React from "react";

/* ─────────────────────────────────────────────
   Types
───────────────────────────────────────────── */
export interface ClientNote {
  id: string;
  acc_name: string;
  acc_ipfclientstatus: string;
  acc_ipfclientstatusLabel: string;
  ownerId: string;
  ownerName: string;
  ownerInitials: string;
  ownerColor: string;
  position: string;
  description: string;
  acc_relatedto: string;
  acc_relatedtoLabel: string;
  createdon: string;
}

interface StatusOption {
  value: string;
  label: string;
  color: string;
}

interface Props {
  dataset: ComponentFramework.PropertyTypes.DataSet;
  clientId: string;
  webAPI: ComponentFramework.WebApi;
  navigation: ComponentFramework.Navigation;
  utils: ComponentFramework.Utility;
  containerWidth: number;
  containerHeight: number;
}

/* ─────────────────────────────────────────────
   Only hardcoded colour is the fallback
───────────────────────────────────────────── */
const DEFAULT_BADGE_COLOR = "#95a5a6";

/* ─────────────────────────────────────────────
   Avatar colours
───────────────────────────────────────────── */
const AVATAR_COLOURS = [
  "#3498db", "#2ecc71", "#e74c3c", "#9b59b6",
  "#f39c12", "#1abc9c", "#e67e22", "#34495e",
];

function avatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash += name.charCodeAt(i);
  return AVATAR_COLOURS[hash % AVATAR_COLOURS.length];
}

function initials(name: string): string {
  return name.split(" ").slice(0, 2).map((n) => n[0]?.toUpperCase() ?? "").join("");
}

function fmtDate(iso: string): string {
  if (!iso) return "";
  const d = new Date(iso);
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}

/* ─────────────────────────────────────────────
   Map dataset rows → ClientNote[]
   Both acc_ipfclientstatus and acc_relatedto are
   OptionSet — getFormattedValue() returns the
   option label text automatically.
───────────────────────────────────────────── */
function mapDataset(dataset: ComponentFramework.PropertyTypes.DataSet): ClientNote[] {
  return dataset.sortedRecordIds.map((id) => {
    const rec = dataset.records[id];

    const getStr = (col: string): string => {
      try { return rec.getFormattedValue(col) ?? ""; } catch { return ""; }
    };
    const getRaw = (col: string): string => {
      try {
        const v = rec.getValue(col);
        return v != null ? String(v) : "";
      } catch { return ""; }
    };

    const ownerFull = getStr("ownerid") || "Unknown";

    // OptionSet: getRaw gives integer value, getStr gives label text
    const statusVal = getRaw("acc_ipfclientstatus");
    const statusLabel = getStr("acc_ipfclientstatus") || statusVal;

    // acc_relatedto is now OptionSet — getFormattedValue returns option label
    const relatedToVal = getRaw("acc_relatedto");
    const relatedToLabel = getStr("acc_relatedto") || relatedToVal;

    // Extract owner GUID for position lookup
    const ownerRef = rec.getValue("ownerid") as any;
    const ownerId: string =
      ownerRef?.id?.guid ?? ownerRef?.id ?? getRaw("_ownerid_value") ?? "";

    return {
      id,
      acc_name: getStr("acc_name") || "(No Title)",
      acc_ipfclientstatus: statusVal,
      acc_ipfclientstatusLabel: statusLabel,
      ownerId,
      ownerName: ownerFull,
      ownerInitials: initials(ownerFull),
      ownerColor: avatarColor(ownerFull),
      position: "",
      description: getStr("description"),
      acc_relatedto: relatedToVal,
      acc_relatedtoLabel: relatedToLabel,
      createdon: getRaw("createdon"),
    };
  });
}

/* ─────────────────────────────────────────────
   Fetch option set metadata for acc_ipfclientstatus
   Returns full StatusOption[] with value, label, color
───────────────────────────────────────────── */
async function fetchStatusOptions(
  webAPI: ComponentFramework.WebApi
): Promise<StatusOption[]> {
  try {
    const result = await (webAPI as any).retrieveMultipleRecords(
      undefined,
      `/EntityDefinitions(LogicalName='acc_clientnote')/Attributes(LogicalName='acc_ipfclientstatus')/Microsoft.Dynamics.CRM.PicklistAttributeMetadata?$select=LogicalName&$expand=OptionSet($select=Options)`
    );
    const options: any[] =
      result?.OptionSet?.Options ??
      result?.entities?.[0]?.OptionSet?.Options ??
      [];

    return options.map((opt: any) => {
      const value = String(opt.Value ?? "");
      const label = opt.Label?.UserLocalizedLabel?.Label ?? opt.Label?.LocalizedLabels?.[0]?.Label ?? value;
      const raw = opt.Color ?? opt.color ?? null;
      let color = DEFAULT_BADGE_COLOR;
      if (raw !== null && raw !== undefined) {
        color = typeof raw === "number"
          ? "#" + ((raw & 0xffffff) >>> 0).toString(16).padStart(6, "0")
          : String(raw).startsWith("#") ? raw : `#${raw}`;
      }
      return { value, label, color };
    });
  } catch {
    return [];
  }
}

/* ─────────────────────────────────────────────
   Fetch owner job titles — batch by unique GUIDs
───────────────────────────────────────────── */
async function fetchOwnerPositions(
  webAPI: ComponentFramework.WebApi,
  ownerIds: string[]
): Promise<Record<string, string>> {
  if (ownerIds.length === 0) return {};
  try {
    const unique = [...new Set(ownerIds.filter(Boolean))];
    if (unique.length === 0) return {};
    const filter = unique.map((id) => `systemuserid eq '${id}'`).join(" or ");
    const result = await webAPI.retrieveMultipleRecords(
      "systemuser",
      `?$select=systemuserid,jobtitle&$filter=${filter}`
    );
    const map: Record<string, string> = {};
    for (const u of result.entities ?? []) {
      map[u["systemuserid"]] = u["jobtitle"] ?? "";
    }
    return map;
  } catch {
    return {};
  }
}

/* ─────────────────────────────────────────────
   Main component
───────────────────────────────────────────── */
export const ClientNoteTimelineComponent: React.FC<Props> = ({
  dataset,
  clientId,
  webAPI,
  navigation,
  containerWidth,
  containerHeight,
}) => {
  const [notes, setNotes] = React.useState<ClientNote[]>([]);
  const [filtered, setFiltered] = React.useState<ClientNote[]>([]);
  const [search, setSearch] = React.useState("");
  const [statusOptions, setStatusOptions] = React.useState<StatusOption[]>([]);
  const [activeStatusFilters, setActiveStatusFilters] = React.useState<Set<string>>(new Set());
  const [positionMap, setPositionMap] = React.useState<Record<string, string>>({});
  const [filterOpen, setFilterOpen] = React.useState(false);

  /* ── Build color map from statusOptions ── */
  const statusColorMap = React.useMemo(() => {
    const m: Record<string, string> = {};
    statusOptions.forEach((o) => { m[o.value] = o.color; });
    return m;
  }, [statusOptions]);

  const getStatusColor = React.useCallback(
    (value: string): string => statusColorMap[value] ?? DEFAULT_BADGE_COLOR,
    [statusColorMap]
  );

  /* ── Fetch status options once ── */
  React.useEffect(() => {
    fetchStatusOptions(webAPI).then(setStatusOptions);
  }, [webAPI]);

  /* ── Map dataset rows whenever dataset updates ── */
  React.useEffect(() => {
    if (!dataset.loading) {
      const mapped = mapDataset(dataset);
      setNotes(mapped);
      const ownerIds = [...new Set(mapped.map((n) => n.ownerId).filter(Boolean))];
      fetchOwnerPositions(webAPI, ownerIds).then(setPositionMap);
    }
  }, [dataset, dataset.loading, dataset.sortedRecordIds]);

  /* ── Apply search + status filter ── */
  React.useEffect(() => {
    const q = search.toLowerCase();
    let result = notes;

    // Status filter — if any chips active, show only matching
    if (activeStatusFilters.size > 0) {
      result = result.filter((n) => activeStatusFilters.has(n.acc_ipfclientstatus));
    }

    // Text search
    if (q) {
      result = result.filter(
        (n) =>
          n.acc_name.toLowerCase().includes(q) ||
          n.description.toLowerCase().includes(q) ||
          n.ownerName.toLowerCase().includes(q) ||
          n.acc_ipfclientstatusLabel.toLowerCase().includes(q) ||
          n.acc_relatedtoLabel.toLowerCase().includes(q)
      );
    }

    setFiltered(result);
  }, [search, notes, activeStatusFilters]);

  /* ── Toggle a status filter chip ── */
  const toggleStatusFilter = React.useCallback((value: string) => {
    setActiveStatusFilters((prev) => {
      const next = new Set(prev);
      if (next.has(value)) { next.delete(value); } else { next.add(value); }
      return next;
    });
  }, []);

  const clearFilters = React.useCallback(() => {
    setActiveStatusFilters(new Set());
  }, []);

  const handleRefresh = React.useCallback(() => { dataset.refresh(); }, [dataset]);

  const openRecord = React.useCallback((id: string) => {
    navigation.openForm({ entityName: "acc_clientnote", entityId: id });
  }, [navigation]);

  const createNew = React.useCallback(() => {
    navigation.openForm({ entityName: "acc_clientnote" }, { acc_clientid: clientId });
  }, [navigation, clientId]);

  const isLoading = dataset.loading;
  const activeCount = activeStatusFilters.size;

  /* ─────────────────────────────────────────
     Render
  ───────────────────────────────────────── */
  return (
    <div style={{
      ...styles.wrapper,
      width: containerWidth > 0 ? containerWidth : "100%",
      minHeight: containerHeight > 0 ? containerHeight : 400,
    }}>

      {/* ── Toolbar ── */}
      <div style={styles.toolbar}>
        <span style={styles.title}>Timeline</span>
        <div style={styles.toolbarRight}>
          <button style={styles.btnPrimary} onClick={createNew}>
            <span style={styles.btnIcon}>+</span> New Client Note
          </button>
          <button style={styles.btnSecondary} onClick={handleRefresh}>
            ↻ Refresh
          </button>
        </div>
      </div>

      {/* ── Search + Filter row ── */}
      <div style={styles.filterRow}>
        {/* Search */}
        <div style={styles.searchWrapper}>
          <span style={styles.searchIcon}>🔍</span>
          <input
            style={styles.searchInput}
            placeholder="Search Timeline"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* IPF Client Status filter — matches the "Related to: 3,4,5 ▽" in the image */}
        <div style={styles.filterGroup}>
          <button
            style={{
              ...styles.filterToggle,
              borderColor: activeCount > 0 ? "#0078d4" : "#d2d0ce",
              color: activeCount > 0 ? "#0078d4" : "#201f1e",
              backgroundColor: activeCount > 0 ? "#eff6fc" : "#fff",
            }}
            onClick={() => setFilterOpen((o) => !o)}
          >
            {activeCount > 0
              ? `Status: ${[...activeStatusFilters]
                  .map((v) => statusOptions.find((o) => o.value === v)?.label ?? v)
                  .join(", ")}`
              : "Filter by Status"}
            <span style={{ marginLeft: 5, fontSize: 11 }}>▾</span>
          </button>

          {/* Clear button when filters active */}
          {activeCount > 0 && (
            <button style={styles.clearBtn} onClick={clearFilters} title="Clear filters">✕</button>
          )}

          {/* Dropdown panel */}
          {filterOpen && (
            <div style={styles.filterDropdown}>
              <div style={styles.filterDropdownHeader}>
                <span style={{ fontSize: 12, fontWeight: 600, color: "#201f1e" }}>IPF Client Status</span>
                <button style={styles.filterCloseBtn} onClick={() => setFilterOpen(false)}>✕</button>
              </div>
              <div style={styles.filterOptions}>
                {statusOptions.length === 0 && (
                  <div style={{ fontSize: 12, color: "#a19f9d", padding: "6px 0" }}>Loading options…</div>
                )}
                {statusOptions.map((opt) => {
                  const active = activeStatusFilters.has(opt.value);
                  return (
                    <div
                      key={opt.value}
                      style={{
                        ...styles.filterOption,
                        backgroundColor: active ? opt.color + "22" : "transparent",
                        borderColor: active ? opt.color : "transparent",
                      }}
                      onClick={() => toggleStatusFilter(opt.value)}
                    >
                      <span style={{
                        ...styles.filterOptionDot,
                        backgroundColor: opt.color,
                      }} />
                      <span style={{ fontSize: 12, flex: 1, color: "#201f1e" }}>{opt.label}</span>
                      {active && <span style={{ fontSize: 11, color: opt.color, fontWeight: 700 }}>✓</span>}
                    </div>
                  );
                })}
              </div>
              {activeCount > 0 && (
                <button style={styles.clearAllBtn} onClick={clearFilters}>Clear all filters</button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Body ── */}
      {isLoading && <div style={styles.stateMsg}>Loading client notes…</div>}

      {!isLoading && filtered.length === 0 && (
        <div style={styles.stateMsg}>
          {activeCount > 0 ? "No client notes match the selected filters." : "No client notes found."}
        </div>
      )}

      {!isLoading && filtered.length > 0 && (
        <div style={styles.timeline}>
          {filtered.map((note, idx) => (
            <TimelineCard
              key={note.id}
              note={{ ...note, position: positionMap[note.ownerId] || note.position || "SPO" }}
              isLast={idx === filtered.length - 1}
              onOpen={openRecord}
              badgeColor={getStatusColor(note.acc_ipfclientstatus)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

/* ─────────────────────────────────────────────
   Timeline Card
───────────────────────────────────────────── */
interface CardProps {
  note: ClientNote;
  isLast: boolean;
  onOpen: (id: string) => void;
  badgeColor: string;
}

const TimelineCard: React.FC<CardProps> = ({ note, isLast, onOpen, badgeColor }) => {
  const [hovered, setHovered] = React.useState(false);

  return (
    <div style={styles.cardRow}>
      <div style={styles.avatarCol}>
        <div style={{ ...styles.avatar, backgroundColor: note.ownerColor }}>
          {note.ownerInitials}
        </div>
        {!isLast && <div style={styles.connector} />}
      </div>

      <div
        style={{
          ...styles.card,
          boxShadow: hovered ? "0 2px 12px rgba(0,0,0,0.12)" : "0 1px 4px rgba(0,0,0,0.06)",
        }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
      >
        <div style={styles.cardInner}>
          <div style={styles.cardLeft}>
            <div style={styles.cardHeader}>
              <span style={styles.noteTitle}>{note.acc_name}</span>
              <span style={styles.noteDate}>{fmtDate(note.createdon)}</span>
            </div>
            <div style={styles.byLine}>Created by {note.ownerName}, {note.position}</div>
            <p style={styles.description as React.CSSProperties}>{note.description}</p>
          </div>

          <div style={styles.cardRight}>
            <div style={styles.relatedLabel}>Related to:</div>
            {note.acc_relatedtoLabel ? (
              <button
                style={{ ...styles.statusBadge, backgroundColor: badgeColor }}
                onClick={() => onOpen(note.id)}
                title="Open Client Note"
              >
                {note.acc_relatedtoLabel}
              </button>
            ) : (
              <span style={styles.noRelated}>—</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────
   Styles
───────────────────────────────────────────── */
const styles: Record<string, React.CSSProperties> = {
  wrapper: {
    fontFamily: "'Segoe UI', system-ui, sans-serif",
    fontSize: 14, color: "#201f1e", backgroundColor: "#ffffff",
    display: "flex", flexDirection: "column",
    boxSizing: "border-box", overflow: "hidden",
  },
  toolbar: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "10px 16px", borderBottom: "1px solid #edebe9", flexShrink: 0,
  },
  title: { fontWeight: 600, fontSize: 16, color: "#201f1e" },
  toolbarRight: { display: "flex", gap: 8, alignItems: "center" },
  btnPrimary: {
    display: "flex", alignItems: "center", gap: 6, padding: "6px 14px",
    backgroundColor: "#ffffff", border: "2px solid #d63384", borderRadius: 4,
    color: "#201f1e", fontWeight: 600, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap",
  },
  btnIcon: { fontSize: 16, color: "#d63384", fontWeight: 700, lineHeight: 1 },
  btnSecondary: {
    display: "flex", alignItems: "center", gap: 4, padding: "6px 12px",
    backgroundColor: "#ffffff", border: "1px solid #d2d0ce", borderRadius: 4,
    color: "#201f1e", fontSize: 13, cursor: "pointer", whiteSpace: "nowrap",
  },

  /* Filter row */
  filterRow: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "8px 16px", flexShrink: 0, gap: 8,
  },
  searchWrapper: {
    display: "flex", alignItems: "center",
    border: "1px solid #d2d0ce", borderRadius: 4,
    padding: "4px 8px", gap: 6, backgroundColor: "#faf9f8", width: 220,
  },
  searchIcon: { fontSize: 13, color: "#a19f9d" },
  searchInput: {
    border: "none", outline: "none", background: "transparent",
    fontSize: 13, color: "#201f1e", width: "100%",
  },

  /* Status filter group */
  filterGroup: {
    position: "relative", display: "flex", alignItems: "center", gap: 4,
  },
  filterToggle: {
    display: "flex", alignItems: "center", gap: 4,
    padding: "5px 10px", borderRadius: 4, border: "1px solid #d2d0ce",
    fontSize: 12, cursor: "pointer", whiteSpace: "nowrap",
    transition: "all 0.15s",
  },
  clearBtn: {
    width: 22, height: 22, borderRadius: "50%", border: "1px solid #d2d0ce",
    background: "#fff", fontSize: 10, cursor: "pointer",
    display: "flex", alignItems: "center", justifyContent: "center",
    color: "#605e5c",
  },
  filterDropdown: {
    position: "absolute", top: "calc(100% + 4px)", right: 0,
    background: "#fff", border: "1px solid #e1dfdd",
    borderRadius: 6, boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
    zIndex: 999, minWidth: 220, padding: "8px 0",
  },
  filterDropdownHeader: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "4px 12px 8px", borderBottom: "1px solid #f3f2f1",
  },
  filterCloseBtn: {
    background: "none", border: "none", cursor: "pointer",
    fontSize: 12, color: "#605e5c",
  },
  filterOptions: { padding: "4px 0" },
  filterOption: {
    display: "flex", alignItems: "center", gap: 8,
    padding: "7px 12px", cursor: "pointer",
    border: "1px solid transparent", margin: "2px 6px",
    borderRadius: 4, transition: "background 0.1s",
  },
  filterOptionDot: {
    width: 10, height: 10, borderRadius: "50%", flexShrink: 0,
  },
  clearAllBtn: {
    width: "calc(100% - 24px)", margin: "6px 12px 2px",
    padding: "5px 0", background: "none",
    border: "1px solid #d2d0ce", borderRadius: 4,
    fontSize: 12, color: "#605e5c", cursor: "pointer",
  },

  /* Timeline */
  timeline: {
    flex: 1, overflowY: "auto", padding: "8px 16px 16px",
    width: "100%", boxSizing: "border-box",
  },
  cardRow: {
    display: "flex", alignItems: "flex-start", gap: 12,
    width: "100%", boxSizing: "border-box",
  },
  avatarCol: {
    display: "flex", flexDirection: "column",
    alignItems: "center", flexShrink: 0, paddingTop: 16,
  },
  avatar: {
    width: 36, height: 36, borderRadius: "50%",
    display: "flex", alignItems: "center", justifyContent: "center",
    color: "#fff", fontWeight: 700, fontSize: 13, flexShrink: 0, zIndex: 1,
  },
  connector: { width: 2, flex: 1, minHeight: 24, backgroundColor: "#e1dfdd" },
  card: {
    flex: 1, minWidth: 0, border: "1px solid #edebe9", borderRadius: 6,
    padding: "14px 16px", backgroundColor: "#ffffff",
    transition: "box-shadow 0.15s ease", marginBottom: 16, marginTop: 8,
    boxSizing: "border-box",
  },
  cardInner: { display: "flex", gap: 16, alignItems: "flex-start", width: "100%" },
  cardLeft: { flex: 1, minWidth: 0 },
  cardHeader: { display: "flex", alignItems: "baseline", gap: 10, marginBottom: 2 },
  noteTitle: { fontWeight: 700, fontSize: 14, color: "#201f1e" },
  noteDate: { fontSize: 12, color: "#605e5c" },
  byLine: { fontSize: 12, color: "#605e5c", marginBottom: 6 },
  description: {
    fontSize: 13, color: "#323130", lineHeight: 1.5, margin: 0,
    display: "-webkit-box", WebkitLineClamp: 3,
    WebkitBoxOrient: "vertical", overflow: "hidden",
  },
  cardRight: {
    flexShrink: 0, width: 130, display: "flex",
    flexDirection: "column", alignItems: "flex-end", gap: 6,
  },
  relatedLabel: { fontSize: 12, fontWeight: 600, color: "#201f1e", textAlign: "right" },
  statusBadge: {
    padding: "6px 10px", borderRadius: 4, color: "#ffffff",
    fontSize: 12, fontWeight: 600, textAlign: "center", border: "none",
    cursor: "pointer", width: "100%", lineHeight: 1.4,
    wordBreak: "break-word", transition: "opacity 0.15s ease",
  },
  noRelated: { fontSize: 12, color: "#a19f9d" },
  stateMsg: { padding: "32px 16px", textAlign: "center", color: "#605e5c", fontSize: 13 },
};
