import { IInputs, IOutputs } from "./generated/ManifestTypes";

// ─────────────────────────────────────────────────────────────────────────────
// CONFIG — mirrors CONFIG in your OffenderFlags web resource exactly
// ─────────────────────────────────────────────────────────────────────────────
const CONFIG = {
  entityLogicalName: "acc_client",
  relationshipName:  "acc_client_acc_clientflag",  // N:N nav property name
  flagPrimaryKey:    "acc_clientflagid",
};

// ─────────────────────────────────────────────────────────────────────────────
// CSS — copied from :root in your web resource
// Inlined as constants since PCF controls cannot inject global <style> tags
// ─────────────────────────────────────────────────────────────────────────────
const CSS = {
  font:        "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
  iconBg:      "#F5F4F0",
  iconBorder:  "#E8E6DF",
  iconColor:   "#A19F9D",
  pillBg:      "#F5F4F0",
  pillBorder:  "#E8E6DF",
  pillText:    "#605E5C",
  textHint:    "#A19F9D",
};

// ─────────────────────────────────────────────────────────────────────────────
// FALLBACK SVG — identical to FALLBACK_SVG in your web resource
// ─────────────────────────────────────────────────────────────────────────────
const FALLBACK_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
  style="width:13px;height:13px;display:block">
  <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
  <line x1="4" y1="22" x2="4" y2="15"/>
</svg>`;

// ─────────────────────────────────────────────────────────────────────────────
// MODULE-LEVEL SVG CACHE
// Shared across all rows in the view — identical to _svgCache in your web resource.
// One fetch per unique icon URL for the entire page session.
// ─────────────────────────────────────────────────────────────────────────────
const _svgCache = new Map<string, string>();

/**
 * Fetch an SVG web resource and return its markup.
 * Identical logic to fetchSvg() in your web resource.
 */
async function fetchSvg(url: string): Promise<string> {
  if (!url) return FALLBACK_SVG;

  const resolved = url.startsWith("http")
    ? url
    : window.location.origin + (url.startsWith("/") ? url : "/" + url);

  if (_svgCache.has(resolved)) return _svgCache.get(resolved)!;

  try {
    const res = await fetch(resolved, { credentials: "same-origin" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();

    const match = text.match(/<svg[\s\S]*<\/svg>/i);
    const svg   = match ? match[0] : FALLBACK_SVG;
    const sized = svg.replace(/<svg/, '<svg style="width:13px;height:13px;display:block" ');

    _svgCache.set(resolved, sized);
    return sized;
  } catch (err) {
    console.warn("[ClientFlagViewer] SVG fetch failed:", resolved, (err as Error).message);
    _svgCache.set(resolved, FALLBACK_SVG);
    return FALLBACK_SVG;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE-LEVEL FLAG DEFINITIONS CACHE
// Mirrors loadFlagDefinitions() + prefetchAllIcons() in your web resource.
// Loaded once per page — shared across every row in the view.
// ─────────────────────────────────────────────────────────────────────────────
interface FlagDef {
  id:          string;
  name:        string;
  description: string;
  iconUrl:     string;
}

let _flagDefs:    FlagDef[] | null = null;
let _flagDefsMap: Map<string, FlagDef> = new Map(); // id (lowercase) → def
let _flagDefsJob: Promise<FlagDef[]> | null = null;

/**
 * Load all active acc_clientflag definitions and pre-fetch their SVG icons.
 * Returns cached result on every subsequent call.
 * Mirrors loadFlagDefinitions() + prefetchAllIcons() in your web resource.
 */
function loadFlagDefinitions(webApi: ComponentFramework.WebApi): Promise<FlagDef[]> {
  if (_flagDefs)    return Promise.resolve(_flagDefs);
  if (_flagDefsJob) return _flagDefsJob;

  _flagDefsJob = webApi
    .retrieveMultipleRecords(
      "acc_clientflag",
      "?$select=acc_clientflagid,acc_name,acc_description,acc_iconurl" +
      "&$filter=acc_isactive eq true" +
      "&$orderby=acc_name asc"
    )
    .then(async (result) => {
      const defs: FlagDef[] = (result.entities || []).map((e: any) => ({
        id:          (e.acc_clientflagid as string).replace(/[{}]/g, "").toLowerCase(),
        name:        (e.acc_name        || "Unnamed Flag") as string,
        description: (e.acc_description || "") as string,
        iconUrl:     ((e.acc_iconurl    || "") as string).trim(),
      }));

      // Pre-fetch all unique icon SVGs in parallel
      // Mirrors prefetchAllIcons() in your web resource
      const uniqueUrls = [...new Set(defs.map(d => d.iconUrl).filter(Boolean))];
      await Promise.allSettled(uniqueUrls.map(url => fetchSvg(url)));

      // Build id lookup
      defs.forEach(d => _flagDefsMap.set(d.id, d));

      _flagDefs = defs;
      return defs;
    })
    .catch((err) => {
      console.error("[ClientFlagViewer] Failed to load flag definitions:", err);
      _flagDefsJob = null; // allow retry
      return [] as FlagDef[];
    });

  return _flagDefsJob;
}

// ─────────────────────────────────────────────────────────────────────────────
// loadActiveFlags
// Mirrors loadActiveFlags() in your web resource.
// Single WebAPI call using $expand on the N:N relationship to get
// the GUIDs of flags linked to this specific client record.
// ─────────────────────────────────────────────────────────────────────────────
async function loadActiveFlags(
  webApi: ComponentFramework.WebApi,
  recordId: string
): Promise<Set<string>> {
  const result = await webApi.retrieveRecord(
    CONFIG.entityLogicalName,
    recordId,
    `?$select=${CONFIG.entityLogicalName}id` +
    `&$expand=${CONFIG.relationshipName}($select=${CONFIG.flagPrimaryKey})`
  );

  const related: any[] = result[CONFIG.relationshipName] || [];

  return new Set(
    related
      .map((r: any) => (r[CONFIG.flagPrimaryKey] || "").replace(/[{}]/g, "").toLowerCase())
      .filter(Boolean)
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PCF CONTROL
// ─────────────────────────────────────────────────────────────────────────────
export class ClientFlagViewer
  implements ComponentFramework.StandardControl<IInputs, IOutputs>
{
  private _root:       HTMLDivElement;
  private _webApi!:    ComponentFramework.WebApi;
  private _lastId:     string = "";
  private _destroyed:  boolean = false;

  // ── init ──────────────────────────────────────────────────────────────────
  public init(
    context:             ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    _state:              ComponentFramework.Dictionary,
    container:           HTMLDivElement
  ): void {
    this._webApi = (context as any).webAPI;

    this._root = document.createElement("div");
    this._root.style.cssText =
      `display:flex;flex-wrap:wrap;gap:4px;align-items:center;` +
      `padding:2px 0;font-family:${CSS.font};`;
    container.appendChild(this._root);

    // Start loading flag definitions immediately so SVG icons are
    // pre-cached before the first row renders — same as your web resource
    if (this._webApi) {
      loadFlagDefinitions(this._webApi);
    }
  }

  // ── updateView ────────────────────────────────────────────────────────────
  public updateView(context: ComponentFramework.Context<IInputs>): void {
    if (!this._webApi) {
      this._renderEmpty("WebAPI unavailable");
      return;
    }

    // The PCF is bound to the primary key field.
    // context.mode.rowSpan / entityId gives us the record GUID in a view.
    const recordId = (context as any).mode?.entityId as string | undefined;

    if (!recordId) {
      this._renderEmpty();
      return;
    }

    const cleanId = recordId.replace(/[{}]/g, "").toLowerCase();

    // Skip if same record — avoids redundant fetches while scrolling
    if (cleanId === this._lastId) return;
    this._lastId = cleanId;

    // Show a subtle loading state while we fetch
    this._renderLoading();

    // Load flag definitions (cached after first call) and active flags
    // for this specific record in parallel — mirrors your web resource bootstrap
    Promise.all([
      loadFlagDefinitions(this._webApi),
      loadActiveFlags(this._webApi, cleanId),
    ])
      .then(([_defs, activeIds]) => {
        if (this._destroyed) return;
        this._renderBadges(activeIds);
      })
      .catch((err) => {
        console.error("[ClientFlagViewer] updateView error:", err);
        if (!this._destroyed) this._renderEmpty("Error loading flags");
      });
  }

  // ── _renderLoading ────────────────────────────────────────────────────────
  private _renderLoading(): void {
    this._root.innerHTML = "";
    const dot = document.createElement("span");
    dot.style.cssText =
      `font-size:11px;color:${CSS.textHint};font-family:${CSS.font};`;
    dot.textContent = "…";
    this._root.appendChild(dot);
  }

  // ── _renderEmpty ──────────────────────────────────────────────────────────
  private _renderEmpty(msg = "—"): void {
    this._root.innerHTML = "";
    const span = document.createElement("span");
    span.style.cssText =
      `font-size:11px;color:${CSS.textHint};font-family:${CSS.font};`;
    span.textContent = msg === "—" ? "—" : msg;
    this._root.appendChild(span);
  }

  // ── _renderBadges ─────────────────────────────────────────────────────────
  // Renders one pill badge per active flag for this record.
  // Badge style mirrors .summary-chip + .flag-icon-wrap in your web resource.
  private _renderBadges(activeIds: Set<string>): void {
    this._root.innerHTML = "";

    if (activeIds.size === 0) {
      this._renderEmpty();
      return;
    }

    activeIds.forEach(flagId => {
      const def = _flagDefsMap.get(flagId);
      const name = def?.name || flagId; // graceful fallback to ID if def missing

      // ── Pill ──────────────────────────────────────────────────────────────
      // Mirrors .summary-chip in your web resource
      const pill = document.createElement("span");
      pill.title = def?.description ? `${name}: ${def.description}` : name;
      pill.style.cssText =
        `display:inline-flex;align-items:center;gap:5px;` +
        `padding:2px 8px 2px 4px;border-radius:999px;` +
        `font-size:10px;font-weight:500;font-family:${CSS.font};` +
        `background:${CSS.pillBg};color:${CSS.pillText};` +
        `border:.5px solid ${CSS.pillBorder};white-space:nowrap;line-height:1.4;`;

      // ── Icon wrap ─────────────────────────────────────────────────────────
      // Mirrors .flag-icon-wrap in your web resource
      const iconWrap = document.createElement("span");
      iconWrap.style.cssText =
        `width:20px;height:20px;border-radius:5px;` +
        `display:inline-flex;align-items:center;justify-content:center;` +
        `background:${CSS.iconBg};border:.5px solid ${CSS.iconBorder};` +
        `color:${CSS.iconColor};flex-shrink:0;`;

      // Use cached SVG — pre-fetched by loadFlagDefinitions()
      const resolved = def?.iconUrl
        ? (def.iconUrl.startsWith("http")
            ? def.iconUrl
            : window.location.origin +
              (def.iconUrl.startsWith("/") ? def.iconUrl : "/" + def.iconUrl))
        : null;

      const cachedSvg = resolved ? _svgCache.get(resolved) : null;
      iconWrap.innerHTML = cachedSvg || FALLBACK_SVG;

      // Edge case: icon wasn't cached yet — fetch and patch in place
      if (def?.iconUrl && !cachedSvg) {
        fetchSvg(def.iconUrl).then(svg => {
          if (!this._destroyed) iconWrap.innerHTML = svg;
        });
      }

      // ── Label ─────────────────────────────────────────────────────────────
      const label = document.createElement("span");
      label.textContent = name;

      pill.appendChild(iconWrap);
      pill.appendChild(label);
      this._root.appendChild(pill);
    });
  }

  // ── getOutputs ────────────────────────────────────────────────────────────
  public getOutputs(): IOutputs {
    return {};
  }

  // ── destroy ───────────────────────────────────────────────────────────────
  public destroy(): void {
    this._destroyed = true;
  }
}
