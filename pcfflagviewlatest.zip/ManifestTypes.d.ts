/*
  Stub — regenerate with:  npm run refreshTypes
  after running:  pac pcf init
*/
export interface IInputs {
  clientId: ComponentFramework.PropertyTypes.WholeNumberProperty;
}
export interface IOutputs {}
