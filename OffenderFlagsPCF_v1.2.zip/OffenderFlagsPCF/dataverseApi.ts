/**
 * dataverseApi.ts
 *
 * Direct Dataverse WebApi helpers for the OffenderFlagsPCF.
 * No Power Automate. No intermediate text field.
 *
 * Reads existing N:N links via retrieveRecord + $expand.
 * Writes via context.webAPI.associateRecord / disassociateRecord.
 */

export interface AssociationConfig {
  entityLogicalName: string;     // e.g. "contact" or "cr_offender"
  entitySetName: string;         // e.g. "contacts" (OData plural)
  recordId: string;              // GUID of the current offender record
  relatedCollectionName: string; // N:N nav property, e.g. "cr_contact_clientflag"
  flagEntitySetName: string;     // e.g. "cr_clientflags"
}

export function cleanGuid(guid: string): string {
  return (guid ?? "").replace(/[{}]/g, "").toLowerCase();
}

export function deriveEntitySetName(logicalName: string): string {
  if (!logicalName) return "";
  if (logicalName.endsWith("y")) return logicalName.slice(0, -1) + "ies";
  if (/[sxz]$/.test(logicalName)) return logicalName + "es";
  return logicalName + "s";
}

/**
 * Loads GUIDs of flag records already linked to the offender via the N:N
 * relationship. Single round-trip using $expand on the offender record.
 *
 * OData equivalent:
 *   GET /contacts({id})?$select=contactid
 *       &$expand=cr_contact_clientflag($select=cr_clientflagid)
 */
export async function loadExistingFlagIds(
  webApi: ComponentFramework.WebApi,
  config: AssociationConfig
): Promise<Set<string>> {
  if (!config.recordId) return new Set<string>();

  const recordId = cleanGuid(config.recordId);
  const expand   = config.relatedCollectionName;
  const select   = `${config.entityLogicalName}id`;

  const response = await webApi.retrieveRecord(
    config.entityLogicalName,
    recordId,
    `?$select=${select}&$expand=${expand}($select=cr_clientflagid)`
  );

  const related: Array<Record<string, string>> = (response as any)[expand] ?? [];

  return new Set<string>(
    related.map((r) => cleanGuid(r["cr_clientflagid"] ?? "")).filter(Boolean)
  );
}
