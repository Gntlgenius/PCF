import * as React from "react";
import { FlagRecord, SEVERITY_COLORS, getIconSvg } from "./flagConfig";

// ─── Props ────────────────────────────────────────────────────────────────────

export interface FlagSelectorProps {
  flags: FlagRecord[];
  activeIds: Set<string>;
  isReadOnly: boolean;
  isLoading: boolean;
  /** Called with (flagId, isCurrentlyActive) when user confirms a toggle */
  onToggle: (flagId: string, isCurrentlyActive: boolean) => Promise<void>;
}

interface DialogState {
  open: boolean;
  flag: FlagRecord | null;
  isRemoving: boolean;
}

// ─── Icon ─────────────────────────────────────────────────────────────────────

const FlagIcon: React.FC<{ iconName: string; size?: number }> = ({ iconName, size = 16 }) => (
  <span
    aria-hidden="true"
    style={{ width: size, height: size, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}
    dangerouslySetInnerHTML={{ __html: getIconSvg(iconName) }}
  />
);

// ─── Toggle ───────────────────────────────────────────────────────────────────

const Toggle: React.FC<{ active: boolean; color: string; saving: boolean }> = ({ active, color, saving }) => (
  <div
    aria-hidden="true"
    style={{
      width: 36, height: 20, borderRadius: 999,
      background: saving ? "#C8C6C4" : active ? color : "#C8C6C4",
      position: "relative", flexShrink: 0,
      transition: "background 0.18s",
      opacity: saving ? 0.5 : 1,
    }}
  >
    <div style={{
      position: "absolute", top: 2,
      left: active ? 18 : 2,
      width: 16, height: 16, borderRadius: "50%",
      background: "#fff",
      transition: "left 0.18s",
    }} />
  </div>
);

// ─── Flag row ─────────────────────────────────────────────────────────────────

const FlagRow: React.FC<{
  flag: FlagRecord;
  isActive: boolean;
  isSaving: boolean;
  isReadOnly: boolean;
  onClick: () => void;
}> = ({ flag, isActive, isSaving, isReadOnly, onClick }) => {
  const colors = SEVERITY_COLORS[flag.severity];
  const [hovered, setHovered] = React.useState(false);
  const disabled = isReadOnly || isSaving;

  const rowBg = isActive
    ? colors.bg
    : hovered && !disabled
    ? "var(--color-background-secondary, #f5f4f0)"
    : "var(--color-background-primary, #fff)";

  return (
    <div
      role="button"
      tabIndex={disabled ? -1 : 0}
      aria-pressed={isActive}
      aria-busy={isSaving}
      aria-label={`${flag.name} — ${isActive ? "active, click to remove" : "inactive, click to add"}`}
      onClick={disabled ? undefined : onClick}
      onKeyDown={(e) => {
        if (!disabled && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); onClick(); }
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "flex", alignItems: "center", gap: 10,
        padding: "11px 14px",
        background: rowBg,
        cursor: disabled ? "default" : "pointer",
        transition: "background 0.15s",
        borderBottom: "0.5px solid var(--color-border-tertiary, #e8e6df)",
        outline: "none",
        minWidth: 0,
        opacity: isSaving ? 0.6 : 1,
      }}
    >
      {/* Icon badge */}
      <div style={{
        width: 34, height: 34, borderRadius: 8,
        background: isActive ? colors.iconBg : "var(--color-background-secondary, #f5f4f0)",
        border: `0.5px solid ${isActive ? colors.iconBorder : "var(--color-border-tertiary, #e8e6df)"}`,
        display: "flex", alignItems: "center", justifyContent: "center",
        color: isActive ? colors.text : "var(--color-text-secondary, #8a8880)",
        transition: "all 0.15s", flexShrink: 0,
      }}>
        <FlagIcon iconName={flag.iconName} size={16} />
      </div>

      {/* Text */}
      <div style={{ flex: 1, minWidth: 0, overflow: "hidden" }}>
        <div style={{
          fontSize: 13, fontWeight: 500,
          color: isActive ? colors.text : "var(--color-text-primary, #201f1e)",
          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
          lineHeight: 1.3, transition: "color 0.15s",
        }}>
          {flag.name}
        </div>
        {flag.description ? (
          <div style={{
            fontSize: 11, marginTop: 2, lineHeight: 1.4,
            color: isActive ? colors.text : "var(--color-text-tertiary, #a19f9d)",
            whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
            opacity: isActive ? 0.8 : 1,
          }}>
            {flag.description}
          </div>
        ) : null}
      </div>

      {/* Status badge */}
      <div style={{
        fontSize: 11, fontWeight: 500, padding: "3px 8px", borderRadius: 999, flexShrink: 0,
        background: isActive ? colors.iconBg : "var(--color-background-secondary, #f5f4f0)",
        color: isActive ? colors.text : "var(--color-text-tertiary, #a19f9d)",
        border: `0.5px solid ${isActive ? colors.iconBorder : "var(--color-border-tertiary, #e8e6df)"}`,
        marginRight: 8, transition: "all 0.15s",
      }}>
        {isSaving ? "Saving…" : isActive ? "Active" : "Inactive"}
      </div>

      <Toggle active={isActive} color={colors.toggleOn} saving={isSaving} />
    </div>
  );
};

// ─── Confirm dialog ───────────────────────────────────────────────────────────

const ConfirmDialog: React.FC<{
  state: DialogState;
  onConfirm: () => void;
  onCancel: () => void;
}> = ({ state, onConfirm, onCancel }) => {
  const confirmRef = React.useRef<HTMLButtonElement>(null);
  React.useEffect(() => { if (state.open) confirmRef.current?.focus(); }, [state.open]);
  if (!state.open || !state.flag) return null;

  const { flag, isRemoving } = state;
  const colors = SEVERITY_COLORS[flag.severity];

  return (
    <div
      role="dialog" aria-modal="true"
      aria-labelledby="ofpcf-dlg-title" aria-describedby="ofpcf-dlg-desc"
      onKeyDown={(e) => { if (e.key === "Escape") onCancel(); }}
      style={{
        position: "fixed", inset: 0,
        background: "rgba(0,0,0,0.36)",
        display: "flex", alignItems: "center", justifyContent: "center",
        zIndex: 9999,
      }}
    >
      <div style={{
        background: "var(--color-background-primary, #fff)",
        border: "0.5px solid var(--color-border-secondary, rgba(0,0,0,0.2))",
        borderRadius: 12, padding: "22px 22px 18px",
        width: 340, maxWidth: "90vw",
      }}>
        <div style={{
          width: 42, height: 42, borderRadius: 10,
          background: colors.iconBg, border: `0.5px solid ${colors.iconBorder}`,
          display: "flex", alignItems: "center", justifyContent: "center",
          color: colors.text, marginBottom: 14,
        }}>
          <FlagIcon iconName={flag.iconName} size={18} />
        </div>

        <div id="ofpcf-dlg-title" style={{ fontSize: 15, fontWeight: 500, color: "var(--color-text-primary, #201f1e)", marginBottom: 8 }}>
          {isRemoving ? `Remove "${flag.name}" flag?` : `Add "${flag.name}" flag?`}
        </div>

        <div id="ofpcf-dlg-desc" style={{ fontSize: 13, color: "var(--color-text-secondary, #605e5c)", lineHeight: 1.55, marginBottom: 20 }}>
          {isRemoving
            ? `This will remove the "${flag.name}" flag from this offender's risk profile. You can re-add it at any time.`
            : `${flag.description ? flag.description + " " : ""}Adding this flag will update the risk profile immediately.`
          }
        </div>

        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
          <button onClick={onCancel} style={{
            padding: "7px 16px", borderRadius: 6, fontSize: 13, fontWeight: 500, cursor: "pointer",
            border: "0.5px solid var(--color-border-secondary, rgba(0,0,0,0.25))",
            background: "var(--color-background-primary, #fff)",
            color: "var(--color-text-primary, #201f1e)",
          }}>
            Cancel
          </button>
          <button ref={confirmRef} onClick={onConfirm} style={{
            padding: "7px 16px", borderRadius: 6, fontSize: 13, fontWeight: 500,
            cursor: "pointer", border: "none",
            background: isRemoving ? "#605e5c" : colors.toggleOn,
            color: "#fff",
          }}>
            {isRemoving ? "Remove flag" : "Add flag"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Summary bar ──────────────────────────────────────────────────────────────

const SummaryBar: React.FC<{ flags: FlagRecord[]; activeIds: Set<string> }> = ({ flags, activeIds }) => {
  const active = flags.filter((f) => activeIds.has(f.id));
  return (
    <div
      aria-live="polite" aria-atomic="true"
      style={{
        padding: "9px 14px",
        background: "var(--color-background-secondary, #f5f4f0)",
        borderTop: "0.5px solid var(--color-border-tertiary, #e8e6df)",
        fontSize: 12,
        display: "flex", alignItems: "center", flexWrap: "wrap", gap: 6,
        borderRadius: "0 0 10px 10px",
        color: active.length > 0 ? "var(--color-text-primary, #201f1e)" : "var(--color-text-tertiary, #a19f9d)",
      }}
    >
      {active.length === 0 ? (
        <span>No risk flags active on this profile.</span>
      ) : (
        <>
          <span style={{ fontWeight: 500, color: "#791F1F" }}>
            {active.length} flag{active.length !== 1 ? "s" : ""} active:
          </span>
          {active.map((f) => {
            const c = SEVERITY_COLORS[f.severity];
            return (
              <span key={f.id} style={{
                fontSize: 11, padding: "2px 8px", borderRadius: 999,
                background: c.iconBg, color: c.text, border: `0.5px solid ${c.iconBorder}`,
              }}>
                {f.name}
              </span>
            );
          })}
        </>
      )}
    </div>
  );
};

// ─── Loading skeleton ─────────────────────────────────────────────────────────

const Skeleton: React.FC = () => (
  <div style={{ padding: "8px 0" }}>
    {[1, 2, 3, 4].map((i) => (
      <div key={i} style={{ display: "flex", gap: 10, alignItems: "center", padding: "10px 14px", borderBottom: "0.5px solid var(--color-border-tertiary, #e8e6df)" }}>
        <div style={{ width: 34, height: 34, borderRadius: 8, background: "var(--color-background-secondary, #f5f4f0)" }} />
        <div style={{ flex: 1 }}>
          <div style={{ height: 12, width: "55%", borderRadius: 4, background: "var(--color-background-secondary, #f5f4f0)", marginBottom: 6 }} />
          <div style={{ height: 10, width: "80%", borderRadius: 4, background: "var(--color-background-secondary, #f5f4f0)" }} />
        </div>
        <div style={{ width: 36, height: 20, borderRadius: 999, background: "var(--color-background-secondary, #f5f4f0)" }} />
      </div>
    ))}
  </div>
);

// ─── Error banner ─────────────────────────────────────────────────────────────

const ErrorBanner: React.FC<{ message: string; onDismiss: () => void }> = ({ message, onDismiss }) => (
  <div role="alert" style={{
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "9px 14px", background: "#FCEBEB",
    border: "0.5px solid #F09595", borderRadius: 8, marginBottom: 8,
    fontSize: 12, color: "#791F1F",
  }}>
    <span>{message}</span>
    <button onClick={onDismiss} aria-label="Dismiss error" style={{
      background: "none", border: "none", cursor: "pointer",
      fontSize: 14, color: "#791F1F", padding: "0 4px", lineHeight: 1,
    }}>×</button>
  </div>
);

// ─── Root component ───────────────────────────────────────────────────────────

export const FlagSelector: React.FC<FlagSelectorProps> = ({
  flags,
  activeIds,
  isReadOnly,
  isLoading,
  onToggle,
}) => {
  const [dialog, setDialog] = React.useState<DialogState>({ open: false, flag: null, isRemoving: false });
  // Track which flag IDs are mid-save (optimistic UI)
  const [savingIds, setSavingIds] = React.useState<Set<string>>(new Set());
  const [errorMessage, setErrorMessage] = React.useState<string | null>(null);

  const openDialog = (flag: FlagRecord) => {
    setDialog({ open: true, flag, isRemoving: activeIds.has(flag.id) });
  };

  const handleConfirm = async () => {
    if (!dialog.flag) return;
    const { flag, isRemoving } = dialog;
    setDialog({ open: false, flag: null, isRemoving: false });

    // Optimistic: mark as saving
    setSavingIds((prev) => new Set(prev).add(flag.id));
    setErrorMessage(null);

    try {
      await onToggle(flag.id, isRemoving);
    } catch (err) {
      const action = isRemoving ? "remove" : "add";
      setErrorMessage(`Failed to ${action} "${flag.name}". Please try again.`);
    } finally {
      setSavingIds((prev) => {
        const next = new Set(prev);
        next.delete(flag.id);
        return next;
      });
    }
  };

  // Split into two columns
  const mid  = Math.ceil(flags.length / 2);
  const col1 = flags.slice(0, mid);
  const col2 = flags.slice(mid);

  return (
    <div style={{ fontFamily: "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif", width: "100%" }}>
      <h2 className="sr-only">Risk flags selector</h2>

      {errorMessage && (
        <ErrorBanner message={errorMessage} onDismiss={() => setErrorMessage(null)} />
      )}

      <div style={{
        border: "0.5px solid var(--color-border-tertiary, #e8e6df)",
        borderRadius: 10, overflow: "hidden",
        background: "var(--color-background-primary, #fff)",
      }}>
        {isLoading ? (
          <Skeleton />
        ) : flags.length === 0 ? (
          <div style={{ padding: "24px 16px", textAlign: "center", fontSize: 13, color: "var(--color-text-tertiary, #a19f9d)" }}>
            No flags configured. Add records to the Client Flags table in Dataverse.
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0 }}>
            {/* Column 1 */}
            <div style={{ borderRight: "0.5px solid var(--color-border-tertiary, #e8e6df)" }}>
              {col1.map((flag, idx) => (
                <div key={flag.id} style={idx === col1.length - 1 ? { borderBottom: "none" } : {}}>
                  <FlagRow
                    flag={flag}
                    isActive={activeIds.has(flag.id)}
                    isSaving={savingIds.has(flag.id)}
                    isReadOnly={isReadOnly}
                    onClick={() => openDialog(flag)}
                  />
                </div>
              ))}
            </div>

            {/* Column 2 */}
            <div>
              {col2.map((flag, idx) => (
                <div key={flag.id} style={idx === col2.length - 1 ? { borderBottom: "none" } : {}}>
                  <FlagRow
                    flag={flag}
                    isActive={activeIds.has(flag.id)}
                    isSaving={savingIds.has(flag.id)}
                    isReadOnly={isReadOnly}
                    onClick={() => openDialog(flag)}
                  />
                </div>
              ))}
              {/* Pad shorter column */}
              {col2.length < col1.length && (
                <div style={{ background: "var(--color-background-secondary, #f5f4f0)", minHeight: 57 }} />
              )}
            </div>
          </div>
        )}

        <SummaryBar flags={flags} activeIds={activeIds} />
      </div>

      <ConfirmDialog
        state={dialog}
        onConfirm={handleConfirm}
        onCancel={() => setDialog({ open: false, flag: null, isRemoving: false })}
      />
    </div>
  );
};

export default FlagSelector;
