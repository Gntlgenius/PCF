// ─── Flag record (loaded dynamically from Dataverse) ──────────────────────────

export interface FlagRecord {
  id: string;                            // cr_clientflagid (GUID)
  name: string;                          // cr_name
  description: string;                   // cr_description
  iconName: string;                      // cr_iconname keyword
  severity: "high" | "medium" | "info"; // mapped from cr_severity option set
}

// ─── Severity option-set mapping ──────────────────────────────────────────────

export const SEVERITY_MAP: Record<number, FlagRecord["severity"]> = {
  1: "high",
  2: "medium",
  3: "info",
};

// ─── Severity colour tokens ────────────────────────────────────────────────────

export const SEVERITY_COLORS: Record<
  FlagRecord["severity"],
  { bg: string; iconBg: string; iconBorder: string; text: string; toggleOn: string }
> = {
  high:   { bg: "#FFF5F5", iconBg: "#FCEBEB", iconBorder: "#F09595", text: "#791F1F", toggleOn: "#E24B4A" },
  medium: { bg: "#FFF8EC", iconBg: "#FAEEDA", iconBorder: "#FAC775", text: "#633806", toggleOn: "#BA7517" },
  info:   { bg: "#EBF4FF", iconBg: "#E6F1FB", iconBorder: "#85B7EB", text: "#0C447C", toggleOn: "#378ADD" },
};

// ─── SVG icon map ──────────────────────────────────────────────────────────────
// Set cr_iconname on the flag record to one of these keys.

const ICON_SVGS: Record<string, string> = {
  hand:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><path d="M18 11V6a2 2 0 0 0-4 0v5"/><path d="M14 10V4a2 2 0 0 0-4 0v6"/><path d="M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M6 14a4 4 0 0 0 4 4h4a4 4 0 0 0 4-4v-2.5"/></svg>`,
  warning: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  eye:     `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
  lock:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,
  shield:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
  block:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>`,
  alert:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
  user:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
  flag:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>`,
};

export function getIconSvg(iconName: string): string {
  return ICON_SVGS[(iconName ?? "").toLowerCase().trim()] ?? ICON_SVGS.flag;
}

// ─── Dataset → FlagRecord mapper ──────────────────────────────────────────────

export function mapEntityToFlag(
  record: ComponentFramework.PropertyHelper.DataSetApi.EntityRecord
): FlagRecord {
  const severityRaw = record.getValue("cr_severity") as number | null;
  return {
    id:          record.getRecordId(),
    name:        (record.getValue("cr_name") as string)        ?? "Unnamed Flag",
    description: (record.getValue("cr_description") as string) ?? "",
    iconName:    (record.getValue("cr_iconname") as string)    ?? "flag",
    severity:    SEVERITY_MAP[severityRaw ?? 0]                ?? "info",
  };
}
