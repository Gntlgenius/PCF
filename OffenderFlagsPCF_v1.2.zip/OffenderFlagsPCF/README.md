# OffenderFlagsPCF v1.2

Dynamic multi-select risk flag PCF for Dataverse model-driven apps.

**Key design in v1.2:** No Power Automate. No intermediate text field.
The PCF writes directly to the N:N relationship via `context.webAPI.associateRecord`
and `context.webAPI.disassociateRecord` — the same API surface used by form scripts.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│  Model-driven form (Contact / cr_Offender)                   │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  OffenderFlagsPCF                                      │  │
│  │                                                        │  │
│  │  On load:   webAPI.retrieveRecord + $expand            │  │
│  │             → reads which flags are already linked     │  │
│  │                                                        │  │
│  │  On add:    webAPI.associateRecord(entity, id,         │  │
│  │                       relationship, "cr_clientflags",  │  │
│  │                       flagId)                          │  │
│  │                                                        │  │
│  │  On remove: webAPI.disassociateRecord(entity, id,      │  │
│  │                       relationship, flagId)            │  │
│  └────────────────────────────────────────────────────────┘  │
│                           │                                   │
│              Writes directly to Dataverse                     │
│              N:N intersection table                           │
│              No save required — immediate                     │
└──────────────────────────────────────────────────────────────┘
```

---

## File structure

```
OffenderFlagsPCF/
├── ControlManifest.Input.xml   ← dataset + 4 input properties
├── index.ts                    ← PCF lifecycle, WebApi calls, optimistic state
├── FlagSelector.tsx            ← React: 2-col list, toggles, dialog, error banner
├── flagConfig.ts               ← FlagRecord type, icon SVGs, severity colours
├── dataverseApi.ts             ← loadExistingFlagIds, AssociationConfig
├── css/OffenderFlagsPCF.css
├── package.json
└── tsconfig.json
```

---

## Dataverse setup

### 1. Create the `cr_clientflag` table

| Column display name | Logical name | Type | Notes |
|---|---|---|---|
| Name | `cr_name` | Text | Primary column — shown in the UI |
| Description | `cr_description` | Multiline Text | Shown in confirm dialog |
| Icon Name | `cr_iconname` | Text | Keyword: hand, warning, eye, lock, shield, block, alert, user, flag |
| Severity | `cr_severity` | Choice | 1 = High (red), 2 = Medium (amber), 3 = Info (blue) |
| Is Active | `cr_isactive` | Yes/No | No = hide without deleting, default Yes |

### 2. Create the N:N relationship

Create a **Many-to-Many** relationship:

| Setting | Value |
|---|---|
| Entity 1 | Contact (or `cr_offender`) |
| Entity 2 | Client Flag (`cr_clientflag`) |
| Relationship name | `cr_contact_clientflag` (confirm the auto-generated name) |

Note the **relationship name** and the **navigation property names** — you'll need
them when configuring the PCF on the form.

### 3. Seed flag records

| Name | Icon Name | Severity | Is Active |
|---|---|---|---|
| Hands | `hand` | High (1) | Yes |
| History of PIV | `warning` | High (1) | Yes |
| History of Sexual Offending | `block` | High (1) | Yes |
| History of Stalking / Harassment | `eye` | High (1) | Yes |
| Restricted | `lock` | Medium (2) | Yes |
| Tier 1 Category | `shield` | High (1) | Yes |

---

## Manifest input properties

When adding the PCF to a form, configure these four input properties:

| Property | Example value | Notes |
|---|---|---|
| `recordId` | bound to `contactid` | Primary key field of the offender entity |
| `entityLogicalName` | `contact` | Logical name of the offender entity |
| `relationshipName` | `cr_contact_clientflag` | The N:N relationship logical name |
| `relatedCollectionName` | `cr_contact_clientflag` | Navigation property for $expand (often same as relationship name) |

> **Tip**: In Maker Portal → Relationships → find your N:N relationship.
> The "Relationship name" shown there is what you use for both `relationshipName`
> and `relatedCollectionName`.

---

## How the WebApi write works

### On load
```typescript
// Single round-trip to fetch linked flags
GET /contacts({recordId})
    ?$select=contactid
    &$expand=cr_contact_clientflag($select=cr_clientflagid)
```

### When user adds a flag
```typescript
context.webAPI.associateRecord(
  "contact",                   // entity logical name
  recordId,                    // offender GUID
  "cr_contact_clientflag",     // relationship / navigation property
  "cr_clientflags",            // flag entity set name
  flagId                       // flag GUID to link
);
```

### When user removes a flag
```typescript
context.webAPI.disassociateRecord(
  "contact",                   // entity logical name
  recordId,                    // offender GUID
  "cr_contact_clientflag",     // relationship / navigation property
  flagId                       // flag GUID to unlink
);
```

Writes are **immediate** — they do not require the form to be saved.
The UI uses **optimistic updates**: the toggle flips instantly and rolls back
with an error banner if the API call fails.

---

## Build & deploy

```bash
npm install
npm run start:watch          # local test harness → http://localhost:8181

pac auth create --url https://yourorg.crm.dynamics.com
npm run push                 # pac pcf push --publisher-prefix cr
```

---

## Adding new flags

Zero code changes needed. Simply add a new record to the `cr_clientflag` table
with the appropriate name, icon keyword, severity, and `Is Active = Yes`.
The PCF picks it up on next form load automatically.

To retire a flag: set `Is Active = No`. Existing N:N links are preserved.
