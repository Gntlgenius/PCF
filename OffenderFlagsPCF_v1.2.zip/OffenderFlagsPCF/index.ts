import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import * as ReactDOM from "react-dom";
import { FlagSelector } from "./FlagSelector";
import { FlagRecord, mapEntityToFlag } from "./flagConfig";
import { AssociationConfig, loadExistingFlagIds, deriveEntitySetName } from "./dataverseApi";

export class OffenderFlagsPCF
  implements ComponentFramework.StandardControl<IInputs, IOutputs>
{
  private _context!: ComponentFramework.Context<IInputs>;
  private _container!: HTMLDivElement;
  private _isDestroyed = false;

  // Available flag definitions (from dataset)
  private _flags: FlagRecord[] = [];

  // Currently linked flag IDs (from N:N relationship via WebApi)
  private _activeIds: Set<string> = new Set();

  // Loading states
  private _datasetLoading = true;
  private _associationsLoading = true;

  // Relationship config — resolved from manifest input properties
  private _assocConfig!: AssociationConfig;

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  public async init(
    context: ComponentFramework.Context<IInputs>,
    _notifyOutputChanged: () => void,
    _state: ComponentFramework.Dictionary,
    container: HTMLDivElement
  ): Promise<void> {
    this._context   = context;
    this._container = container;

    // Request up to 250 flag records from the dataset
    context.parameters.clientFlagsDataset.paging.setPageSize(250);

    // Build the association config from manifest input properties
    this._assocConfig = this._buildAssocConfig(context);

    // Initial render (loading state)
    this._renderControl();

    // Load existing flag links from the N:N relationship
    await this._loadAssociations();
  }

  public async updateView(context: ComponentFramework.Context<IInputs>): Promise<void> {
    this._context = context;

    // Refresh association config in case inputs changed
    this._assocConfig = this._buildAssocConfig(context);

    // Load flags from dataset when it finishes loading
    const dataset = context.parameters.clientFlagsDataset;
    if (dataset.loading) {
      this._datasetLoading = true;
    } else {
      this._datasetLoading = false;
      this._flags = this._readFlagsFromDataset(dataset);
    }

    this._renderControl();
  }

  public getOutputs(): IOutputs {
    // No output properties — all writes go directly to Dataverse via WebApi
    return {};
  }

  public destroy(): void {
    this._isDestroyed = true;
    ReactDOM.unmountComponentAtNode(this._container);
  }

  // ── Association config ─────────────────────────────────────────────────────

  private _buildAssocConfig(
    context: ComponentFramework.Context<IInputs>
  ): AssociationConfig {
    const entityLogicalName   = (context.parameters.entityLogicalName?.raw ?? "contact").trim();
    const relatedCollectionName = (context.parameters.relatedCollectionName?.raw ?? "").trim();
    const recordId            = (context.parameters.recordId?.raw ?? "").trim();

    return {
      entityLogicalName,
      entitySetName:        deriveEntitySetName(entityLogicalName),
      recordId,
      relatedCollectionName,
      // cr_clientflags is the standard set name for the cr_clientflag entity
      flagEntitySetName:    "cr_clientflags",
    };
  }

  // ── Load existing associations ─────────────────────────────────────────────

  private async _loadAssociations(): Promise<void> {
    if (!this._assocConfig.recordId) {
      // New record — no associations yet
      this._associationsLoading = false;
      this._renderControl();
      return;
    }

    try {
      this._activeIds = await loadExistingFlagIds(
        this._context.webAPI,
        this._assocConfig
      );
    } catch (err) {
      console.error("[OffenderFlagsPCF] Could not load existing flag associations:", err);
      this._activeIds = new Set();
    } finally {
      this._associationsLoading = false;
      this._renderControl();
    }
  }

  // ── Handle toggle (associate / disassociate) ───────────────────────────────

  /**
   * Called by FlagSelector when the user confirms a toggle.
   * Updates _activeIds optimistically, then calls WebApi.
   * On failure, rolls back and re-renders.
   */
  private async _handleToggle(flagId: string, isCurrentlyActive: boolean): Promise<void> {
    // Optimistic update
    const rollback = new Set(this._activeIds);
    if (isCurrentlyActive) {
      this._activeIds.delete(flagId);
    } else {
      this._activeIds.add(flagId);
    }
    this._renderControl();

    try {
      if (isCurrentlyActive) {
        // Remove: disassociate the flag from the offender record
        await this._context.webAPI.disassociateRecord(
          this._assocConfig.entityLogicalName,
          this._assocConfig.recordId,
          this._assocConfig.relatedCollectionName,
          flagId
        );
      } else {
        // Add: associate the flag to the offender record
        await this._context.webAPI.associateRecord(
          this._assocConfig.entityLogicalName,
          this._assocConfig.recordId,
          this._assocConfig.relatedCollectionName,
          this._assocConfig.flagEntitySetName,
          flagId
        );
      }
    } catch (err) {
      // Roll back on failure — the React component will show the error banner
      this._activeIds = rollback;
      this._renderControl();
      // Re-throw so FlagSelector can show its error banner
      throw err;
    }
  }

  // ── Load flags from dataset ────────────────────────────────────────────────

  private _readFlagsFromDataset(
    dataset: ComponentFramework.PropertyTypes.DataSet
  ): FlagRecord[] {
    const records: FlagRecord[] = [];

    for (const id of dataset.sortedRecordIds) {
      const record = dataset.records[id];
      if (!record) continue;
      // Skip flags marked inactive
      if (record.getValue("cr_isactive") === false) continue;
      try {
        records.push(mapEntityToFlag(record));
      } catch {
        /* skip malformed records */
      }
    }

    // Sort alphabetically for consistent two-column layout
    records.sort((a, b) => a.name.localeCompare(b.name));
    return records;
  }

  // ── Render ─────────────────────────────────────────────────────────────────

  private _renderControl(): void {
    if (this._isDestroyed) return;

    const isReadOnly =
      this._context.parameters.isReadOnly?.raw === true ||
      this._context.mode.isControlDisabled;

    const isLoading = this._datasetLoading || this._associationsLoading;

    ReactDOM.render(
      React.createElement(FlagSelector, {
        flags:      [...this._flags],
        activeIds:  new Set(this._activeIds),
        isReadOnly,
        isLoading,
        onToggle:   this._handleToggle.bind(this),
      }),
      this._container
    );
  }
}
