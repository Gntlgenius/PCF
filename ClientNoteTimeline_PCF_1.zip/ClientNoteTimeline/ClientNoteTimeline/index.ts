import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { ClientNoteTimelineComponent } from "./components/ClientNoteTimeline";

export class ClientNoteTimeline
  implements ComponentFramework.ReactControl<IInputs, IOutputs>
{
  private _context: ComponentFramework.Context<IInputs>;

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void
  ): void {
    this._context = context;
    context.mode.trackContainerResize(true);
  }

  public updateView(
    context: ComponentFramework.Context<IInputs>
  ): React.ReactElement {
    this._context = context;

    // The control lives on the Client form — read the record GUID directly.
    // contextInfo.entityId is the GUID of the current form record.
    const contextInfo = (context.mode as any).contextInfo;
    const clientId: string = contextInfo?.entityId ?? "";

    return React.createElement(ClientNoteTimelineComponent, {
      clientId,
      webAPI: context.webAPI,
      navigation: context.navigation,
      utils: context.utils,
      containerWidth: context.mode.allocatedWidth,
    });
  }

  public getOutputs(): IOutputs {
    return {};
  }

  public destroy(): void {}
}
