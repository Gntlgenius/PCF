import { IInputs, IOutputs } from "./generated/ManifestTypes";

// ─────────────────────────────────────────────────────────────────────────────
// TYPES — JSON shape written by FlagJsonWriter plugin
//
// iconUrl can now be either:
//   (a) A web resource path  e.g. "/WebResources/acc_icon_violence.svg"
//   (b) Inline SVG markup    e.g. "<svg viewBox=...>...</svg>"
//
// The control detects which it is and skips the fetch for (b).
// ─────────────────────────────────────────────────────────────────────────────
interface FlagJsonEntry {
  id:       string;
  name:     string;
  iconUrl:  string;  // URL path OR raw SVG markup
  isActive: boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// CSS
// ─────────────────────────────────────────────────────────────────────────────
const CSS = {
  font:            "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
  iconBg:          "#F5F4F0",
  iconBgHover:     "#ECEAE3",
  iconBorder:      "#E8E6DF",
  iconBorderHover: "#C8C6C4",
  iconColor:       "#605E5C",
  textHint:        "#A19F9D",
  tooltipBg:       "#201F1E",
  tooltipText:     "#FFFFFF",
};

// ─────────────────────────────────────────────────────────────────────────────
// FALLBACK SVG
// ─────────────────────────────────────────────────────────────────────────────
const FALLBACK_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
  style="width:13px;height:13px;display:block">
  <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
  <line x1="4" y1="22" x2="4" y2="15"/>
</svg>`;

// ─────────────────────────────────────────────────────────────────────────────
// SVG HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/** Returns true when the value is inline SVG markup rather than a URL. */
function isInlineSvg(value: string): boolean {
  return value.trimStart().startsWith("<svg");
}

/**
 * Normalise an SVG string to 13×13 px display size.
 * Called for both inline markup and fetched web resource text.
 */
function normaliseSvg(raw: string): string {
  const match = raw.match(/<svg[\s\S]*<\/svg>/i);
  if (!match) return FALLBACK_SVG;
  return match[0].replace(/<svg/, '<svg style="width:13px;height:13px;display:block" ');
}

// ─────────────────────────────────────────────────────────────────────────────
// URL FETCH CACHE — only used when iconUrl is a URL path, not inline SVG.
// Shared across all rows; each URL fetched at most once per page session.
// ─────────────────────────────────────────────────────────────────────────────
const _svgCache    = new Map<string, string>();
const _svgFetching = new Map<string, Promise<string>>();

function resolveUrl(url: string): string {
  if (!url) return "";
  return url.startsWith("http")
    ? url
    : window.location.origin + (url.startsWith("/") ? url : "/" + url);
}

function fetchSvg(url: string): Promise<string> {
  const resolved = resolveUrl(url);
  if (_svgCache.has(resolved))    return Promise.resolve(_svgCache.get(resolved)!);
  if (_svgFetching.has(resolved)) return _svgFetching.get(resolved)!;

  const job = fetch(resolved, { credentials: "same-origin" })
    .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.text(); })
    .then(text => {
      const svg = normaliseSvg(text);
      _svgCache.set(resolved, svg);
      return svg;
    })
    .catch(err => {
      console.warn("[ClientFlagViewer] SVG fetch failed:", resolved, (err as Error).message);
      _svgCache.set(resolved, FALLBACK_SVG);
      return FALLBACK_SVG;
    })
    .finally(() => { _svgFetching.delete(resolved); });

  _svgFetching.set(resolved, job);
  return job;
}

/**
 * Returns the resolved SVG string for a flag entry — synchronously if possible.
 *
 * - Inline SVG  → normalise and return immediately, no fetch.
 * - URL (cached) → return from cache immediately, no fetch.
 * - URL (cold)  → returns null; caller should call fetchSvg() and patch async.
 */
function resolveSvgSync(iconUrl: string): string | null {
  if (!iconUrl) return FALLBACK_SVG;

  // ── Inline SVG path — no fetch needed at all ──────────────────────────────
  if (isInlineSvg(iconUrl)) {
    return normaliseSvg(iconUrl);
  }

  // ── URL path — return from cache if available ─────────────────────────────
  const resolved = resolveUrl(iconUrl);
  return _svgCache.get(resolved) ?? null; // null = not cached yet, fetch async
}

/**
 * Pre-warm the URL fetch cache for any flags that still use URL paths.
 * Inline SVG entries are skipped — nothing to fetch.
 */
function prefetchIcons(flags: FlagJsonEntry[]): void {
  const urls = [...new Set(
    flags
      .map(f => f.iconUrl)
      .filter(v => v && !isInlineSvg(v))
  )];
  urls.forEach(u => fetchSvg(u));
}

// ─────────────────────────────────────────────────────────────────────────────
// TOOLTIP — styled click tooltip with iframe-clip detection fallback
// ─────────────────────────────────────────────────────────────────────────────
let _activeTooltip: HTMLElement | null = null;

function dismissTooltip(): void {
  if (_activeTooltip) {
    _activeTooltip.style.display = "none";
    _activeTooltip = null;
  }
}

if (typeof document !== "undefined") {
  document.addEventListener("click", (e: MouseEvent) => {
    if (_activeTooltip && !_activeTooltip.parentElement!.contains(e.target as Node)) {
      dismissTooltip();
    }
  }, { capture: true });
}

function isFullyVisible(el: HTMLElement): boolean {
  const r = el.getBoundingClientRect();
  return r.top >= 0 && r.left >= 0 && r.bottom <= window.innerHeight && r.right <= window.innerWidth;
}

// ─────────────────────────────────────────────────────────────────────────────
// PCF CONTROL
// ─────────────────────────────────────────────────────────────────────────────
export class ClientFlagViewer
  implements ComponentFramework.StandardControl<IInputs, IOutputs>
{
  private _root:           HTMLDivElement;
  private _lastRaw:        string  = "__UNINIT__";
  private _destroyed:      boolean = false;
  private _useNativeTitle: boolean = false;
  private _buttons: Array<{ btn: HTMLElement; name: string }> = [];

  public init(
    context:             ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    _state:              ComponentFramework.Dictionary,
    container:           HTMLDivElement
  ): void {
    this._root = document.createElement("div");
    this._root.style.cssText =
      `display:flex;flex-wrap:wrap;gap:4px;align-items:center;` +
      `padding:2px 0;font-family:${CSS.font};`;
    container.appendChild(this._root);
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {
    const raw = (context.parameters.flagsJson.raw || "").trim();
    if (raw === this._lastRaw) return;
    this._lastRaw = raw;

    if (!raw) { this._renderEmpty(); return; }

    let allFlags: FlagJsonEntry[];
    try { allFlags = JSON.parse(raw) as FlagJsonEntry[]; }
    catch { this._renderEmpty(); return; }

    if (!Array.isArray(allFlags) || allFlags.length === 0) { this._renderEmpty(); return; }

    // Pre-warm fetch cache for any remaining URL-based icons.
    // No-op if all icons are already inline SVG.
    prefetchIcons(allFlags);

    const active = allFlags.filter(f => f.isActive === true);
    if (active.length === 0) { this._renderEmpty(); return; }

    this._renderIcons(active);
  }

  private _renderEmpty(): void {
    this._root.innerHTML = "";
    const span = document.createElement("span");
    span.style.cssText = `font-size:11px;color:${CSS.textHint};font-family:${CSS.font};`;
    span.textContent = "—";
    this._root.appendChild(span);
  }

  private _renderIcons(flags: FlagJsonEntry[]): void {
    this._root.innerHTML = "";
    this._buttons = [];

    flags.forEach(flag => {
      const wrap = document.createElement("span");
      wrap.style.cssText = `position:relative;display:inline-flex;flex-shrink:0;`;

      const btn = document.createElement("span");
      btn.setAttribute("role", "button");
      btn.setAttribute("tabindex", "0");
      btn.setAttribute("aria-label", flag.name);
      if (this._useNativeTitle) btn.setAttribute("title", flag.name);

      btn.style.cssText =
        `width:26px;height:26px;border-radius:6px;` +
        `display:inline-flex;align-items:center;justify-content:center;` +
        `background:${CSS.iconBg};border:.5px solid ${CSS.iconBorder};` +
        `color:${CSS.iconColor};cursor:pointer;flex-shrink:0;` +
        `transition:background .12s,border-color .12s;`;

      btn.addEventListener("mouseenter", () => {
        btn.style.background  = CSS.iconBgHover;
        btn.style.borderColor = CSS.iconBorderHover;
      });
      btn.addEventListener("mouseleave", () => {
        btn.style.background  = CSS.iconBg;
        btn.style.borderColor = CSS.iconBorder;
      });

      // ── Styled tooltip ────────────────────────────────────────────────────
      const tip = document.createElement("span");
      tip.textContent = flag.name;
      tip.style.cssText =
        `display:none;position:absolute;` +
        `bottom:calc(100% + 6px);left:50%;transform:translateX(-50%);` +
        `background:${CSS.tooltipBg};color:${CSS.tooltipText};` +
        `font-size:11px;font-weight:500;font-family:${CSS.font};` +
        `white-space:nowrap;padding:4px 8px;border-radius:6px;` +
        `pointer-events:none;z-index:9999;`;

      const caret = document.createElement("span");
      caret.style.cssText =
        `position:absolute;top:100%;left:50%;transform:translateX(-50%);` +
        `border:4px solid transparent;border-top-color:${CSS.tooltipBg};`;
      tip.appendChild(caret);

      const handleClick = (e: Event) => {
        e.stopPropagation();
        if (this._useNativeTitle) return;
        if (_activeTooltip === tip) { dismissTooltip(); return; }
        dismissTooltip();
        tip.style.display = "block";
        _activeTooltip    = tip;

        requestAnimationFrame(() => {
          if (this._destroyed) return;
          if (!isFullyVisible(tip)) {
            dismissTooltip();
            this._useNativeTitle = true;
            this._buttons.forEach(({ btn: b, name }) => b.setAttribute("title", name));
          }
        });
      };

      btn.addEventListener("click",   handleClick);
      btn.addEventListener("keydown", (e: KeyboardEvent) => {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); handleClick(e); }
      });

      // ── SVG icon — sync if inline or cached, async only for cold URL ──────
      const svgSync = resolveSvgSync(flag.iconUrl);

      if (svgSync !== null) {
        // Inline SVG or already-cached URL — render immediately, zero latency
        btn.innerHTML = svgSync;
      } else {
        // Cold URL — show fallback now, patch in real icon when fetch completes
        btn.innerHTML = FALLBACK_SVG;
        fetchSvg(flag.iconUrl).then(svg => {
          if (!this._destroyed) btn.innerHTML = svg;
        });
      }

      this._buttons.push({ btn, name: flag.name });
      wrap.appendChild(btn);
      wrap.appendChild(tip);
      this._root.appendChild(wrap);
    });
  }

  public getOutputs(): IOutputs { return {}; }

  public destroy(): void {
    this._destroyed = true;
    dismissTooltip();
  }
}
