import { IInputs, IOutputs } from "./generated/ManifestTypes";

// ─────────────────────────────────────────────────────────────────────────────
// CONFIG
// ─────────────────────────────────────────────────────────────────────────────
const CONFIG = {
  entityLogicalName: "acc_client",
  relationshipName:  "acc_client_acc_clientflag",
  flagPrimaryKey:    "acc_clientflagid",
};

// ─────────────────────────────────────────────────────────────────────────────
// CSS
// ─────────────────────────────────────────────────────────────────────────────
const CSS = {
  font:       "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
  iconBg:     "#F5F4F0",
  iconBorder: "#E8E6DF",
  iconColor:  "#A19F9D",
  pillBg:     "#F5F4F0",
  pillBorder: "#E8E6DF",
  pillText:   "#605E5C",
  textHint:   "#A19F9D",
};

// ─────────────────────────────────────────────────────────────────────────────
// FALLBACK SVG
// Used when acc_svgcontent is blank on the flag record.
// ─────────────────────────────────────────────────────────────────────────────
const FALLBACK_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
  style="width:13px;height:13px;display:block">
  <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
  <line x1="4" y1="22" x2="4" y2="15"/>
</svg>`;

/**
 * Normalise raw SVG markup so it always renders at 13×13 px inside the
 * icon wrap. Called once per flag def when definitions are loaded.
 */
function normaliseSvg(raw: string): string {
  const match = raw.match(/<svg[\s\S]*<\/svg>/i);
  if (!match) return FALLBACK_SVG;
  return match[0].replace(/<svg/, '<svg style="width:13px;height:13px;display:block" ');
}

// ─────────────────────────────────────────────────────────────────────────────
// FLAG DEFINITIONS — module-level, shared across every row in the view.
//
// acc_clientflag now stores SVG markup directly in acc_svgcontent
// (a multiline text field). This eliminates all per-icon HTTP fetches —
// the SVG arrives in the single flag-definition API call we already make.
// ─────────────────────────────────────────────────────────────────────────────
interface FlagDef {
  id:          string;  // lowercase GUID, no braces
  name:        string;
  description: string;
  svg:         string;  // ready-to-inject SVG markup (normalised, never empty)
}

let _flagDefs:    FlagDef[] | null         = null;
let _flagDefsMap: Map<string, FlagDef>     = new Map();
let _flagDefsJob: Promise<FlagDef[]> | null = null;

/**
 * Load all active flag definitions (including inline SVG) once per page.
 * Every subsequent call returns the cached promise or resolved value.
 *
 * Requires acc_svgcontent (Multiline Text) on acc_clientflag.
 * If the field is blank the control falls back to FALLBACK_SVG gracefully.
 */
function loadFlagDefinitions(webApi: ComponentFramework.WebApi): Promise<FlagDef[]> {
  if (_flagDefs)    return Promise.resolve(_flagDefs);
  if (_flagDefsJob) return _flagDefsJob;

  _flagDefsJob = webApi
    .retrieveMultipleRecords(
      "acc_clientflag",
      // acc_svgcontent replaces acc_iconurl — SVG markup stored directly on the record
      "?$select=acc_clientflagid,acc_name,acc_description,acc_svgcontent" +
      "&$filter=acc_isactive eq true" +
      "&$orderby=acc_name asc"
    )
    .then((result) => {
      const defs: FlagDef[] = (result.entities || []).map((e: any) => {
        const rawSvg = ((e.acc_svgcontent || "") as string).trim();
        return {
          id:          (e.acc_clientflagid as string).replace(/[{}]/g, "").toLowerCase(),
          name:        (e.acc_name        || "Unnamed Flag") as string,
          description: (e.acc_description || "") as string,
          // Normalise once on load — zero work at render time
          svg:         rawSvg ? normaliseSvg(rawSvg) : FALLBACK_SVG,
        };
      });

      defs.forEach(d => _flagDefsMap.set(d.id, d));
      _flagDefs = defs;
      return defs;
    })
    .catch((err) => {
      console.error("[ClientFlagViewer] Failed to load flag definitions:", err);
      _flagDefsJob = null; // allow retry on next updateView
      return [] as FlagDef[];
    });

  return _flagDefsJob;
}

// ─────────────────────────────────────────────────────────────────────────────
// loadActiveFlags
// Retrieves the GUIDs of flags linked to a specific client record via $expand.
// ─────────────────────────────────────────────────────────────────────────────
async function loadActiveFlags(
  webApi: ComponentFramework.WebApi,
  recordId: string
): Promise<Set<string>> {
  const result = await webApi.retrieveRecord(
    CONFIG.entityLogicalName,
    recordId,
    `?$select=${CONFIG.entityLogicalName}id` +
    `&$expand=${CONFIG.relationshipName}($select=${CONFIG.flagPrimaryKey})`
  );

  const related: any[] = result[CONFIG.relationshipName] || [];
  return new Set(
    related
      .map((r: any) => (r[CONFIG.flagPrimaryKey] || "").replace(/[{}]/g, "").toLowerCase())
      .filter(Boolean)
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PCF CONTROL — virtual
//
// virtual controls must implement ReactControl (returns ReactElement) or
// use the container passed into init. Because we target the PCF standard
// interface (not React) we receive a container div from the framework even
// for virtual — we render into it directly.
// ─────────────────────────────────────────────────────────────────────────────
export class ClientFlagViewer
  implements ComponentFramework.StandardControl<IInputs, IOutputs>
{
  private _container:   HTMLDivElement;
  private _webApi!:     ComponentFramework.WebApi;
  private _lastId:      string  = "";
  private _destroyed:   boolean = false;
  // Token prevents stale async results from a previous row overwriting the current one
  private _fetchToken:  number  = 0;

  public init(
    context:             ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    _state:              ComponentFramework.Dictionary,
    container:           HTMLDivElement
  ): void {
    this._webApi    = context.webAPI;
    this._container = container;

    // virtual: no wrapper div needed — style the container directly
    this._container.style.cssText =
      `display:flex;flex-wrap:wrap;gap:4px;align-items:center;` +
      `padding:2px 0;font-family:${CSS.font};`;

    // Kick off flag definition load immediately so the data (including SVGs)
    // is cached before any row calls updateView
    if (this._webApi) {
      loadFlagDefinitions(this._webApi);
    }
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {
    if (!this._webApi) {
      this._renderEmpty("WebAPI unavailable");
      return;
    }

    // Read the bound property — the only reliable source of the record GUID
    // in a view (context.mode.entityId is only set on forms).
    const rawId = context.parameters.clientId?.raw as string | null | undefined;

    if (!rawId) {
      this._renderEmpty();
      return;
    }

    const cleanId = rawId.replace(/[{}]/g, "").toLowerCase();

    // Skip redundant re-renders for the same record
    if (cleanId === this._lastId) return;
    this._lastId = cleanId;

    this._renderLoading();

    // Increment token — only the response matching the latest token is rendered
    const token = ++this._fetchToken;

    Promise.all([
      loadFlagDefinitions(this._webApi), // resolves instantly after first load
      loadActiveFlags(this._webApi, cleanId),
    ])
      .then(([_defs, activeIds]) => {
        if (this._destroyed || token !== this._fetchToken) return;
        this._renderBadges(activeIds);
      })
      .catch((err) => {
        console.error("[ClientFlagViewer] updateView error:", err);
        if (!this._destroyed && token === this._fetchToken) {
          this._renderEmpty("Error loading flags");
        }
      });
  }

  // ── Render helpers ─────────────────────────────────────────────────────────

  private _renderLoading(): void {
    this._container.innerHTML = "";
    const dot = document.createElement("span");
    dot.style.cssText = `font-size:11px;color:${CSS.textHint};font-family:${CSS.font};`;
    dot.textContent = "…";
    this._container.appendChild(dot);
  }

  private _renderEmpty(msg = "—"): void {
    this._container.innerHTML = "";
    const span = document.createElement("span");
    span.style.cssText = `font-size:11px;color:${CSS.textHint};font-family:${CSS.font};`;
    span.textContent = msg;
    this._container.appendChild(span);
  }

  private _renderBadges(activeIds: Set<string>): void {
    this._container.innerHTML = "";

    if (activeIds.size === 0) {
      this._renderEmpty();
      return;
    }

    activeIds.forEach(flagId => {
      const def  = _flagDefsMap.get(flagId);
      const name = def?.name || flagId;

      // ── Pill ──────────────────────────────────────────────────────────────
      const pill = document.createElement("span");
      pill.title = def?.description ? `${name}: ${def.description}` : name;
      pill.style.cssText =
        `display:inline-flex;align-items:center;gap:5px;` +
        `padding:2px 8px 2px 4px;border-radius:999px;` +
        `font-size:10px;font-weight:500;font-family:${CSS.font};` +
        `background:${CSS.pillBg};color:${CSS.pillText};` +
        `border:.5px solid ${CSS.pillBorder};white-space:nowrap;line-height:1.4;`;

      // ── Icon wrap ─────────────────────────────────────────────────────────
      const iconWrap = document.createElement("span");
      iconWrap.style.cssText =
        `width:20px;height:20px;border-radius:5px;` +
        `display:inline-flex;align-items:center;justify-content:center;` +
        `background:${CSS.iconBg};border:.5px solid ${CSS.iconBorder};` +
        `color:${CSS.iconColor};flex-shrink:0;`;

      // SVG is already normalised and cached on the FlagDef — no fetch needed
      iconWrap.innerHTML = def?.svg || FALLBACK_SVG;

      // ── Label ─────────────────────────────────────────────────────────────
      const label = document.createElement("span");
      label.textContent = name;

      pill.appendChild(iconWrap);
      pill.appendChild(label);
      this._container.appendChild(pill);
    });
  }

  public getOutputs(): IOutputs {
    return {};
  }

  public destroy(): void {
    this._destroyed = true;
  }
}
